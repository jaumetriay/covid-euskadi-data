<?php

namespace App\Http\Controllers;
use Algorithmia;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB; 
use App\Models\User;
use App\Models\Phone;
use SimpleXMLElement; 
use DOMXPath; 
use DOMDocument; 

use Illuminate\Support\Facades\Artisan;
use App\Models\CountCovid; 
use App\Models\Deceased; 
use Illuminate\Support\Facades\Log;
use Carbon\Carbon;
 

use App\Console\Commands\Scheduler; 
class Covid extends Controller
{      
 
    public function figure()
    {
 
       //echo Carbon::now();
       //Artisan::call('schedule:work');

        $cvd = CountCovid::all();  
       $deceased = Deceased::all();  
        
        return view('figure', compact('cvd', 'deceased')); 
    }

 
 

 
    
}
 
<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Models\CountCovid;
use App\Models\Deceased;  
use SimpleXMLElement; 

class Scheduler extends Command
{

 
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'scheduler:update';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
     


        //$fileName = "covid19-byage.xml"; 
       
        //$xml = new SimpleXMLElement(public_path('xml\\') . $fileName, null, true); 
        $xml = new SimpleXMLElement('https://opendata.euskadi.eus/contenidos/ds_informes_estudios/covid_19_2020/opendata/generated/covid19-byage.xml', null, true);

        $positiveCount = $xml->xpath('//positiveCounts/positiveCount');
        $positiveMenCount = $xml->xpath('//positiveMenCounts/positiveMenCount'); 
        $positiveWomenCount = $xml->xpath('//psitiveWomenCounts/positiveWomenCount'); //"PSitive" is not a error, XML typo. 


        
        $deceasedTotal =  $xml->xpath('//deceasedCounts/deceasedCount');
        $deceasedMen =  $xml->xpath('//deceasedMenCounts/deceasedMenCount');
        $deceasedWomen =  $xml->xpath('//deceasedWomenCounts/deceasedWomenCount');
        
   
        // $populationTotal =  $xml->xpath('//positivesByPopulationRates/positivesByPopulationRate');
        // $populationMen =  $xml->xpath('//positivesByMenPopulationRates/positivesByMenPopulationRate');
        // $populationWomen =  $xml->xpath('//positivesByWomenPopulationRates/positivesByWomenPopulationRate');

        $ageRange = $xml->xpath('//allAgeRanges/anAgeRange');  
 
        $this->updateAllCount($positiveMenCount, $positiveWomenCount, $positiveCount, $ageRange);
        $this->updateAllDeceased($deceasedMen, $deceasedWomen, $deceasedTotal, $ageRange); 
 

    }

   

    public function updateAllCount($menCount, $womenCount, $totalCount, $ageRange)
    {        
        CountCovid::getQuery()->delete();
        
        for($i = 0;  $i < count($menCount); $i++)
        {
            $count = new CountCovid; 

            $count->ageRange = $ageRange[$i];  
    
            $count->menCount = $menCount[$i]; 
            $count->womenCount = $womenCount[$i]; 
            $count->totalCount = $totalCount[$i];  

            $count->save(); 
 
        }

        
         
    }

    public function updateAllDeceased($menDeceased, $womenDeceased, $totalDeceased, $ageRange)
    {        
        Deceased::getQuery()->delete();
        
        for($i = 0;  $i < count($menDeceased); $i++)
        {
            $deceased = new Deceased; 

            $deceased->ageRange = $ageRange[$i];  
    
            $deceased->deceasedMen = $menDeceased[$i]; 
            $deceased->deceasedWomen = $womenDeceased[$i]; 
            $deceased->deceasedTotal = $totalDeceased[$i];  

            $deceased->save(); 
 
        }

        
         
    }
 

}

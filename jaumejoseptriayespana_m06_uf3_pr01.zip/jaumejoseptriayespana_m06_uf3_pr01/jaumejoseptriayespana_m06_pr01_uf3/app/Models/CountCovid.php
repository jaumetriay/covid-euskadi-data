<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CountCovid extends Model
{
    use HasFactory;
    public $timestamps = false;
    protected $table = 'count_covid';  
    protected $primaryKey = 'id';
}

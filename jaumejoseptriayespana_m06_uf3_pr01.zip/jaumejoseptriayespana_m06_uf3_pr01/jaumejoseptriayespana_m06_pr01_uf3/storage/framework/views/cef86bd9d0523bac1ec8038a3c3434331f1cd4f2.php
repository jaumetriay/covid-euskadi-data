<head>
<meta charset=utf-8 />
<title>Morris.js Area Chart</title>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('spam.css')); ?>" >
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('figure.css')); ?>" >


<link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.css">
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.0/jquery.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.min.js"></script>


</head>
 <body>  
 <h1 class="title-margin">POSITVE COVID CASES BY AGE AND GENDER</h1>
 <div id="chart0"></div>

 <h1 class="title-margin">COVID DECEASED BY AGE AND GENDER</h1>
 <div id="chart1"></div>  
 <!-- <div id="chart2"></div>   -->
    
 </body>
 <script> 
new Morris.Line({
  // ID of the element in which to draw the chart.
  element: 'chart0',
  // Chart data records -- each entry in this array corresponds to a point on
  // the chart.
  data: [
    <?php 
            foreach($cvd as $c)
                echo "{ageRange: '" . $c->ageRange . "', womenPositive: " . $c->womenCount . ", menPositive: " . $c->menCount . ", totalPositive: " . $c->totalCount . "},";
            
     ?>
 
  ],
 
  parseTime: false, //per X axis !LIKE DATETYPE 
  
  xkey: 'ageRange',
  
  // A list of names of data record attributes that contain y-values.
  ykeys: ['womenPositive','menPositive', 'totalPositive'],
 
  // Labels for the ykeys -- will be displayed when you hover over the
  // chart.
  labels: ['Positive women by age ', 'Positive men by age', 'Total by age']
});

new Morris.Line({
  // ID of the element in which to draw the chart.
  element: 'chart1',
  // Chart data records -- each entry in this array corresponds to a point on
  // the chart.
  data: [
    <?php 
            foreach($deceased as $d)
                echo "{ageRange: '" . $d->ageRange . "', womenDeceased: " . $d->deceasedWomen . ", menDeceased: " . $d->deceasedMen . ", totalDeceased: " . $d->deceasedTotal . "},";
            
     ?>
 
  ],
 
  parseTime: false, //per X axis !LIKE DATETYPE 
  
  xkey: 'ageRange',
  
  // A list of names of data record attributes that contain y-values.
  ykeys: ['womenDeceased','menDeceased', 'totalDeceased'],
 
  // Labels for the ykeys -- will be displayed when you hover over the
  // chart.
  labels: ['Deceased women by age ', 'Deceased men by age', 'Deceased Total by age']
});


 
 
 </script>

 <?php /**PATH C:\Users\Jaume\Desktop\Treball\DAM\2020-2021\M06-PHP\m06_pr01_uf3\resources\views/figure.blade.php ENDPATH**/ ?>
<html xmlns="http://www.w3.org/1999/xhtml" lang="es" xml:lang="es"><head>
	    <title>SALLENET: Módulo de Alumnos</title>
	    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<meta http-equiv="Expires" content="0">
		<meta http-equiv="Last-Modified" content="0">
		<meta http-equiv="Cache-Control" content="no-cache, mustrevalidate">
		<meta http-equiv="Pragma" content="no-cache">
		<link rel="stylesheet" type="text/css" href="https://gracia.sallenet.org/mod/sallenet/bootstrap/css/bootstrap.css">
		<link rel="stylesheet" type="text/css" href="https://gracia.sallenet.org/mod/sallenet/bootstrap/css/bootstrap-theme.css">
		<link rel="stylesheet" type="text/css" href="https://gracia.sallenet.org/mod/sallenet/css/sallenet.css">
		<link rel="stylesheet" type="text/css" href="https://gracia.sallenet.org/mod/sallenet/css/calidad.css">
		<link rel="stylesheet" type="text/css" href="https://gracia.sallenet.org/mod/sallenet/css/jquery-ui.css">
		<link rel="stylesheet" type="text/css" href="https://gracia.sallenet.org/mod/sallenet/font-awesome/css/font-awesome.min.css">
		<link rel="stylesheet" type="text/css" href="https://gracia.sallenet.org/mod/sallenet/css/bootstrap-clockpicker.min.css">
		<link rel="stylesheet" type="text/css" href="https://gracia.sallenet.org/mod/sallenet/calendario/css/jornada.css">
		
		<!--CSS Incluidos por david-->
		<link rel="stylesheet" type="text/css" href="https://gracia.sallenet.org/mod/sallenet/calendario/css/calendar.css">
		<!--FIN CSS Incluidos por david-->

		<!--CSS Incluidos por Juan-->
		<link rel="stylesheet" type="text/css" href="https://gracia.sallenet.org/mod/sallenet/css/chosen.css">
		<!--FIN CSS Incluidos por Juan-->
		
		<!--CSS Incluidos por Jaime-->
		<link rel="stylesheet" type="text/css" href="https://gracia.sallenet.org/mod/sallenet/css/select2.min.css">
		<!--FIN CSS Incluidos por Jaime-->

		<link rel="stylesheet" type="text/css" href="https://gracia.sallenet.org/mod/sallenet/calendario/css/pick-a-color-1.1.8.min.css">
		<link rel="stylesheet" type="text/css" href="https://gracia.sallenet.org/mod/sallenet/css/datatables.min.css">
		<link rel="stylesheet" type="text/css" href="https://gracia.sallenet.org/mod/sallenet/css/bootstrap-datetimepicker.min.css">

		<!-- Este primero por si acaso -->
		<script type="text/javascript">
			var wwwsallenet = 'https://gracia.sallenet.org/mod/sallenet';
			var lang_sallenet = 'es';
		</script>
		<script type="text/javascript" src="https://gracia.sallenet.org/mod/sallenet/js/sallenet.js"></script>
		<script type="text/javascript" src="https://gracia.sallenet.org/mod/sallenet/js/jquery-2.0.3.min.js"></script>
		<script type="text/javascript" src="https://gracia.sallenet.org/mod/sallenet/js/jquery-ui.js"></script>
		<script type="text/javascript" src="https://gracia.sallenet.org/mod/sallenet/bootstrap/js/bootstrap.min.js"></script>

		<script type="text/javascript" src="https://gracia.sallenet.org/mod/sallenet/js/Chart.min.js"></script>
		<script type="text/javascript" src="https://gracia.sallenet.org/mod/sallenet/js/bootstrap-clockpicker.min.js"></script>
		<script type="text/javascript" src="https://gracia.sallenet.org/mod/sallenet/js/bootstrap-datetimepicker.min.js"></script>
		<script type="text/javascript" src="https://gracia.sallenet.org/mod/sallenet/js/datatables.min.js"></script>
		<script type="text/javascript" src="https://gracia.sallenet.org/mod/sallenet/js/typeahead.js"></script>
		<script type="text/javascript" src="https://gracia.sallenet.org/mod/sallenet/js/script.js?_=20210318"></script>
		<script type="text/javascript" src="https://gracia.sallenet.org/mod/sallenet/js/jquery.ui.touch-punch.min.js"></script>
		<script type="text/javascript" src="https://gracia.sallenet.org/mod/sallenet/js/tinymce/tinymce.min.js"></script>
		
		<!-- Script añadido por Juan -->
		<script type="text/javascript" src="https://gracia.sallenet.org/mod/sallenet/js/chosen.jquery.js"></script>
		<!-- Fin añdido por Juan -->    
    
		<!-- Script añadido por Jaime -->
		<script type="text/javascript" src="https://gracia.sallenet.org/mod/sallenet/js/select2.min.js"></script>
		<!-- Fin añdido por Jaime -->  

		<script type="text/javascript" src="https://gracia.sallenet.org/mod/sallenet/modulos/_js/calidad.js"></script>
		<script type="text/javascript" src="https://gracia.sallenet.org/mod/sallenet/modulos/_js/exportacion.js"></script>
		<script type="text/javascript" src="https://gracia.sallenet.org/mod/sallenet/modulos/_js/reservalibros.js"></script>
		<script type="text/javascript" src="https://gracia.sallenet.org/mod/sallenet/modulos/_js/reservalibrostexto.js"></script>
		<script type="text/javascript" src="https://gracia.sallenet.org/mod/sallenet/modulos/_js/time.js"></script>
		<script type="text/javascript" src="https://gracia.sallenet.org/mod/sallenet/modulos/_js/extraescolar.js"></script>
		<script type="text/javascript" src="https://gracia.sallenet.org/mod/sallenet/modulos/_js/lectura_eficaz.js"></script>
		<script type="text/javascript" src="https://gracia.sallenet.org/mod/sallenet/modulos/_js/facturacion.js"></script>

		<script type="text/javascript" src="https://gracia.sallenet.org/mod/sallenet/inscripciones/inscripciones.js"></script>
		<script type="text/javascript" src="https://gracia.sallenet.org/mod/sallenet/calendario/components/underscore/underscore-min.js"></script>
		<script type="text/javascript" src="https://gracia.sallenet.org/mod/sallenet/calendario/js/tinycolor-0.9.15.min.js"></script>
		<script type="text/javascript" src="https://gracia.sallenet.org/mod/sallenet/calendario/js/pick-a-color-1.1.8.min.js"></script>
		<script type="text/javascript" src="https://gracia.sallenet.org/mod/sallenet/calendario/js/jquery.timepicker.min.js"></script>
		<script type="text/javascript" src="https://gracia.sallenet.org/mod/sallenet/calendario/js/jquery.timepicker.js"></script>

		<!--
		Añadido por J David
		 Global site tag (gtag.js) - Google Analytics Tracking-->
		<script async="" src="https://www.googletagmanager.com/gtag/js?id=NO FOUND"></script>
		<script>
		 window.dataLayer = window.dataLayer || [];
		 function gtag(){dataLayer.push(arguments);}
		 gtag('js', new Date());
		
		 gtag('config', 'NO FOUND');
		</script>
	</head>
	<body class="position: relative;" style="padding-top: 70px;">
		<nav class="navbar navbar-default navbar-fixed-top">
			<div class="container-fluid">
				<!-- Brand and toggle get grouped for better mobile display -->
				<div class="navbar-header">
					<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#sallenet-navbar" aria-expanded="false">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
				      </button>
				      <a class="navbar-brand" href="https://gracia.sallenet.org/mod/sallenet/index.php"><img src="https://gracia.sallenet.org/mod/sallenet/img/estrella.png" height="20px;"> <span class="hidden-sm hidden-xs">SALLENET: Módulo de Alumnos</span> <span title="SALLENET: Módulo de Alumnos" class="glyphicon glyphicon-home hidden-md hidden-lg hidden-xl small"></span></a>
				</div>
				<!-- Collect the nav links, forms, and other content for toggling -->
				<div class="collapse navbar-collapse" id="sallenet-navbar" style="overflow: auto">
					<ul class="nav navbar-nav">
				<li><a title="Alumnos" href="https://gracia.sallenet.org/mod/sallenet/modulos/alumnos"><img class="pull-left" style="float: left; width: 20px;" onmouseout="$(this).css(&quot;filter&quot;,&quot;&quot;);$(this).css(&quot;-webkit-filter&quot;,&quot;&quot;)" onmouseover="$(this).css(&quot;filter&quot;,&quot;grayscale(100%)&quot;);$(this).css(&quot;-webkit-filter&quot;,&quot;grayscale(100%)&quot;)" src="https://gracia.sallenet.org/mod/sallenet/img/alumnos.png" alt="0"><span class="visible-xs" style="float: right">Alumnos</span></a></li>
				<li><a title="Comunicaciones" href="https://gracia.sallenet.org/mod/sallenet/modulos/comunicaciones"><img class="pull-left" style="float: left; width: 20px;" onmouseout="$(this).css(&quot;filter&quot;,&quot;&quot;);$(this).css(&quot;-webkit-filter&quot;,&quot;&quot;)" onmouseover="$(this).css(&quot;filter&quot;,&quot;grayscale(100%)&quot;);$(this).css(&quot;-webkit-filter&quot;,&quot;grayscale(100%)&quot;)" src="https://gracia.sallenet.org/mod/sallenet/img/comunicaciones.png" alt="1"><span class="visible-xs" style="float: right">Comunicaciones</span></a></li>
					</ul>
					
					
					
					<ul class="nav navbar-nav navbar-right">
						<li class="dropdown">
							<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Edición<span class="caret"></span></a>
							<ul class="dropdown-menu">
								<li><a href="#" onclick="AbrirCampos();return false;">Abrir-Cerrar cuadros</a></li>
								<li><a href="#" onclick="GuardaDatosAbiertos();return false;">Guardar datos abiertos</a></li>
							</ul>
						</li>
					</ul>
				</div>
			</div>
		</nav>
		
		<ul class="nav nav-tabs">
        <a href="<?php echo e(url('/incidencias')); ?>"> <span>Incidencias	|	</span></a>	
			<a href="<?php echo e(url('/seguimiento')); ?>"> <span>Seguimiento	|	</span></a>	
			<a href="<?php echo e(url('/calificaciones')); ?>"> <span>Calificaciones	|	</span></a>
			<a href="<?php echo e(url('/boletin')); ?>"> <span>Boletines		|</span></a>
	     
            
		</ul>
		<!-- Tab panes -->
		<div class="tab-content">
			<div class="tab-pane active" id="div_alumnos" style="min-height: 200px;">
		<div class="panel panel-primary">
			<div class="panel-heading">
				<table style="width: 100%;">
					<tbody><tr>
						<td>Boletines on-line 2º - CFGS - Informàtica: Desenvolupament d`aplicacions multiplataforma</td>
						<td style="text-align: right;"></td>
					</tr>
				</tbody></table>
			</div>
			<div class="table-responsive">
				
		<table class="table table-hover">
		<thead>
			<tr>
				<th>Evaluación</th>
				<th>Boletin PDF</th>
			</tr>
		</thead>
		<tbody>
			<tr>
				<td>1a Avaluació</td>
				<td><a id="258303_3600" href="https://gracia.sallenet.org/mod/sallenet/download.php?tipo=7&amp;userid=258303&amp;path=3600.pdf"><img src="https://gracia.sallenet.org/pix/f/pdf.png" alt="pdf"></a></td>
			</tr>
			<tr>
				<td>2a Avaluació</td>
				<td><a id="258303_3601" href="https://gracia.sallenet.org/mod/sallenet/download.php?tipo=7&amp;userid=258303&amp;path=3601.pdf"><img src="https://gracia.sallenet.org/pix/f/pdf.png" alt="pdf"></a></td>
			</tr>
		</tbody>
		</table>
			</div>
		</div></div>
		</div>
		<div class="modal fade" id="Modal">
			<div class="modal-dialog modal-lg">
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
			  			<h4 class="modal-title" id="ModalTitle">Sallenet</h4>
					</div>
					<div class="modal-body" id="ModalBody">
					</div>
				</div>
			</div>
		</div>
        <div class="modal fade" id="ModalMensaje">
			<div class="modal-dialog modal-lg" style="width:40%">
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
			  			<h4 class="modal-title" id="ModalMensajeTitle">Sallenet</h4>
					</div>
					<div class="modal-body" id="ModalMensajeBody">
					</div>
					<div class="modal-footer" id="ModalMensajeFooter" style="\&quot;margin-top:5px;\&quot;">
					</div>
				</div>
			</div>
		</div>
	
	<div id="ui-datepicker-div" class="ui-datepicker ui-widget ui-widget-content ui-helper-clearfix ui-corner-all"></div></body></html><?php /**PATH C:\Users\Jaume\Desktop\Treball\DAM\2020-2021\M06-PHP\newproject-laravel\resources\views/a-boletin.blade.php ENDPATH**/ ?>
 
<html dir="ltr" lang="es" xml:lang="es" class="no-js yui3-js-enabled"><head>
    <title>Sallenet 3.0</title>
    <link rel="shortcut icon" href="https://gracia.sallenet.org/pluginfile.php/1/theme_essential/favicon/1614308938/favicon.ico">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name="keywords" content="moodle, Sallenet 3.0">
<link rel="stylesheet" type="text/css" href="https://gracia.sallenet.org/theme/yui_combo.php?rollup/3.17.2/yui-moodlesimple-min.css"><script type="text/javascript" async="" src="https://www.google-analytics.com/analytics.js"></script><script charset="utf-8" id="yui_3_17_2_1_1616771229552_8" src="https://gracia.sallenet.org/theme/yui_combo.php?m/1614308938/core/event/event-min.js&amp;m/1614308938/filter_mathjaxloader/loader/loader-min.js" async=""></script><script charset="utf-8" id="yui_3_17_2_1_1616771229552_18" src="https://gracia.sallenet.org/theme/yui_combo.php?m/1614308938/core/dock/dock-loader-min.js" async=""></script><link charset="utf-8" rel="stylesheet" id="yui_3_17_2_1_1616771229552_48" href="https://gracia.sallenet.org/theme/yui_combo.php?3.17.2/cssbutton/cssbutton-min.css"><script charset="utf-8" id="yui_3_17_2_1_1616771229552_49" src="https://gracia.sallenet.org/theme/yui_combo.php?m/1614308938/core/widget/widget-focusafterclose-min.js&amp;3.17.2/plugin/plugin-min.js&amp;m/1614308938/core/lockscroll/lockscroll-min.js&amp;m/1614308938/core/notification/notification-dialogue-min.js&amp;m/1614308938/core/tooltip/tooltip-min.js&amp;m/1614308938/core/popuphelp/popuphelp-min.js" async=""></script><script charset="utf-8" id="yui_3_17_2_1_1616771229552_154" src="https://gracia.sallenet.org/theme/yui_combo.php?3.17.2/event-mousewheel/event-mousewheel-min.js&amp;3.17.2/event-resize/event-resize-min.js&amp;3.17.2/event-hover/event-hover-min.js&amp;3.17.2/event-touch/event-touch-min.js&amp;3.17.2/event-move/event-move-min.js&amp;3.17.2/event-flick/event-flick-min.js&amp;3.17.2/event-valuechange/event-valuechange-min.js&amp;3.17.2/event-tap/event-tap-min.js" async=""></script><script charset="utf-8" id="yui_3_17_2_1_1616771229552_158" src="https://cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.2/MathJax.js?delayStartupUntil=configured" async=""></script><script id="firstthemesheet" type="text/css">/** Required in order to fix style inclusion problems in IE with YUI **/</script><link rel="stylesheet" type="text/css" href="https://gracia.sallenet.org/theme/styles.php/essential/1614308938_1614309381/all">
<script type="text/javascript">
//<![CDATA[
var M = {}; M.yui = {};
M.pageloadstarttime = new Date();
 

//]]>
</script>

<!-- Global site tag (gtag.js) - Google Analytics -->
<script async="" src="https://www.googletagmanager.com/gtag/js?id=UA-68479839-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-68479839-1');
</script>
<meta name="description" content="Sallenet 3.0">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Google web fonts -->
        <!-- iOS Homescreen Icons -->
    
<link rel="apple-touch-icon" sizes="57x57" href="//gracia.sallenet.org/pluginfile.php/1/theme_essential/iphoneicon/1614308938/estrella1.png">
<link rel="apple-touch-icon" sizes="72x72" href="//gracia.sallenet.org/pluginfile.php/1/theme_essential/ipadicon/1614308938/estrella2.png">
<link rel="apple-touch-icon" sizes="114x114" href="//gracia.sallenet.org/pluginfile.php/1/theme_essential/iphoneretinaicon/1614308938/estrella3.png">
<link rel="apple-touch-icon" sizes="144x144" href="//gracia.sallenet.org/pluginfile.php/1/theme_essential/ipadretinaicon/1614308938/estrella4.png"><script type="text/x-mathjax-config;executed=true">
MathJax.Hub.Config({
  config: ["MMLorHTML.js"],
  jax: ["input/TeX","input/MathML","input/AsciiMath","output/HTML-CSS","output/NativeMML", "output/PreviewHTML"],
  extensions: ["tex2jax.js","mml2jax.js","asciimath2jax.js","MathMenu.js","MathZoom.js", "fast-preview.js", "AssistiveMML.js", "[Contrib]/a11y/accessibility-menu.js"],
  TeX: {
    extensions: ["AMSmath.js","AMSsymbols.js","noErrors.js","noUndefined.js"]
  }
});</script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="core/first" src="https://gracia.sallenet.org/lib/requirejs.php/1614308938/core/first.js"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="jquery" src="https://gracia.sallenet.org/lib/javascript.php/1614308938/lib/jquery/jquery-3.2.1.min.js"></script><style id="fit-vids-style">.fluid-width-video-wrapper{width:100%;position:relative;padding:0;}.fluid-width-video-wrapper iframe,.fluid-width-video-wrapper object,.fluid-width-video-wrapper embed {position:absolute;top:0;left:0;width:100%;height:100%;}</style><style type="text/css">.MathJax_Preview {color: #888}
#MathJax_Message {position: fixed; left: 1em; bottom: 1.5em; background-color: #E6E6E6; border: 1px solid #959595; margin: 0px; padding: 2px 8px; z-index: 102; color: black; font-size: 80%; width: auto; white-space: nowrap}
#MathJax_MSIE_Frame {position: absolute; top: 0; left: 0; width: 0px; z-index: 101; border: 0px; margin: 0px; padding: 0px}
.MathJax_Error {color: #CC0000; font-style: italic}
</style><style type="text/css">#MathJax_About {position: fixed; left: 50%; width: auto; text-align: center; border: 3px outset; padding: 1em 2em; background-color: #DDDDDD; color: black; cursor: default; font-family: message-box; font-size: 120%; font-style: normal; text-indent: 0; text-transform: none; line-height: normal; letter-spacing: normal; word-spacing: normal; word-wrap: normal; white-space: nowrap; float: none; z-index: 201; border-radius: 15px; -webkit-border-radius: 15px; -moz-border-radius: 15px; -khtml-border-radius: 15px; box-shadow: 0px 10px 20px #808080; -webkit-box-shadow: 0px 10px 20px #808080; -moz-box-shadow: 0px 10px 20px #808080; -khtml-box-shadow: 0px 10px 20px #808080; filter: progid:DXImageTransform.Microsoft.dropshadow(OffX=2, OffY=2, Color='gray', Positive='true')}
#MathJax_About.MathJax_MousePost {outline: none}
.MathJax_Menu {position: absolute; background-color: white; color: black; width: auto; padding: 2px; border: 1px solid #CCCCCC; margin: 0; cursor: default; font: menu; text-align: left; text-indent: 0; text-transform: none; line-height: normal; letter-spacing: normal; word-spacing: normal; word-wrap: normal; white-space: nowrap; float: none; z-index: 201; box-shadow: 0px 10px 20px #808080; -webkit-box-shadow: 0px 10px 20px #808080; -moz-box-shadow: 0px 10px 20px #808080; -khtml-box-shadow: 0px 10px 20px #808080; filter: progid:DXImageTransform.Microsoft.dropshadow(OffX=2, OffY=2, Color='gray', Positive='true')}
.MathJax_MenuItem {padding: 2px 2em; background: transparent}
.MathJax_MenuArrow {position: absolute; right: .5em; padding-top: .25em; color: #666666; font-size: .75em}
.MathJax_MenuActive .MathJax_MenuArrow {color: white}
.MathJax_MenuArrow.RTL {left: .5em; right: auto}
.MathJax_MenuCheck {position: absolute; left: .7em}
.MathJax_MenuCheck.RTL {right: .7em; left: auto}
.MathJax_MenuRadioCheck {position: absolute; left: 1em}
.MathJax_MenuRadioCheck.RTL {right: 1em; left: auto}
.MathJax_MenuLabel {padding: 2px 2em 4px 1.33em; font-style: italic}
.MathJax_MenuRule {border-top: 1px solid #CCCCCC; margin: 4px 1px 0px}
.MathJax_MenuDisabled {color: GrayText}
.MathJax_MenuActive {background-color: Highlight; color: HighlightText}
.MathJax_MenuDisabled:focus, .MathJax_MenuLabel:focus {background-color: #E8E8E8}
.MathJax_ContextMenu:focus {outline: none}
.MathJax_ContextMenu .MathJax_MenuItem:focus {outline: none}
#MathJax_AboutClose {top: .2em; right: .2em}
.MathJax_Menu .MathJax_MenuClose {top: -10px; left: -10px}
.MathJax_MenuClose {position: absolute; cursor: pointer; display: inline-block; border: 2px solid #AAA; border-radius: 18px; -webkit-border-radius: 18px; -moz-border-radius: 18px; -khtml-border-radius: 18px; font-family: 'Courier New',Courier; font-size: 24px; color: #F0F0F0}
.MathJax_MenuClose span {display: block; background-color: #AAA; border: 1.5px solid; border-radius: 18px; -webkit-border-radius: 18px; -moz-border-radius: 18px; -khtml-border-radius: 18px; line-height: 0; padding: 8px 0 6px}
.MathJax_MenuClose:hover {color: white!important; border: 2px solid #CCC!important}
.MathJax_MenuClose:hover span {background-color: #CCC!important}
.MathJax_MenuClose:hover:focus {outline: none}
</style><style type="text/css">#MathJax_Zoom {position: absolute; background-color: #F0F0F0; overflow: auto; display: block; z-index: 301; padding: .5em; border: 1px solid black; margin: 0; font-weight: normal; font-style: normal; text-align: left; text-indent: 0; text-transform: none; line-height: normal; letter-spacing: normal; word-spacing: normal; word-wrap: normal; white-space: nowrap; float: none; -webkit-box-sizing: content-box; -moz-box-sizing: content-box; box-sizing: content-box; box-shadow: 5px 5px 15px #AAAAAA; -webkit-box-shadow: 5px 5px 15px #AAAAAA; -moz-box-shadow: 5px 5px 15px #AAAAAA; -khtml-box-shadow: 5px 5px 15px #AAAAAA; filter: progid:DXImageTransform.Microsoft.dropshadow(OffX=2, OffY=2, Color='gray', Positive='true')}
#MathJax_ZoomOverlay {position: absolute; left: 0; top: 0; z-index: 300; display: inline-block; width: 100%; height: 100%; border: 0; padding: 0; margin: 0; background-color: white; opacity: 0; filter: alpha(opacity=0)}
#MathJax_ZoomFrame {position: relative; display: inline-block; height: 0; width: 0}
#MathJax_ZoomEventTrap {position: absolute; left: 0; top: 0; z-index: 302; display: inline-block; border: 0; padding: 0; margin: 0; background-color: white; opacity: 0; filter: alpha(opacity=0)}
</style><style type="text/css">.MathJax_Preview .MJXf-math {color: inherit!important}
</style><style type="text/css">.MJX_Assistive_MathML {position: absolute!important; top: 0; left: 0; clip: rect(1px, 1px, 1px, 1px); padding: 1px 0 0 0!important; border: 0!important; height: 1px!important; width: 1px!important; overflow: hidden!important; display: block!important; -webkit-touch-callout: none; -webkit-user-select: none; -khtml-user-select: none; -moz-user-select: none; -ms-user-select: none; user-select: none}
.MJX_Assistive_MathML.MJX_Assistive_MathML_Block {width: 100%!important}
</style><script type="text/javascript">
require(['jquery', 'theme_bootstrapbase/bootstrap'], function($) {
    require(['theme_bootstrapbase/bootstrap'], function() {
        var target = $("#calendar-day-popover-link-1-2021-59-2");
        target.popover({
            content: function() {
                var source = target.next().find("> *:not('.hidden')");
                var content = $('<div>');

                if (source.length) {
                    content.html(source.clone(false));
                } else {
                    content.html(target.data('alternate'));
                }

                return content.html();
            }
        });
    });
});
;

require(['jquery', 'theme_bootstrapbase/bootstrap'], function($) {
    require(['theme_bootstrapbase/bootstrap'], function() {
        var target = $("#calendar-day-popover-link-1-2021-60-2");
        target.popover({
            content: function() {
                var source = target.next().find("> *:not('.hidden')");
                var content = $('<div>');

                if (source.length) {
                    content.html(source.clone(false));
                } else {
                    content.html(target.data('alternate'));
                }

                return content.html();
            }
        });
    });
});
;

require(['jquery', 'theme_bootstrapbase/bootstrap'], function($) {
    require(['theme_bootstrapbase/bootstrap'], function() {
        var target = $("#calendar-day-popover-link-1-2021-62-2");
        target.popover({
            content: function() {
                var source = target.next().find("> *:not('.hidden')");
                var content = $('<div>');

                if (source.length) {
                    content.html(source.clone(false));
                } else {
                    content.html(target.data('alternate'));
                }

                return content.html();
            }
        });
    });
});
;

require(['jquery', 'theme_bootstrapbase/bootstrap'], function($) {
    require(['theme_bootstrapbase/bootstrap'], function() {
        var target = $("#calendar-day-popover-link-1-2021-63-2");
        target.popover({
            content: function() {
                var source = target.next().find("> *:not('.hidden')");
                var content = $('<div>');

                if (source.length) {
                    content.html(source.clone(false));
                } else {
                    content.html(target.data('alternate'));
                }

                return content.html();
            }
        });
    });
});
;

require(['jquery', 'theme_bootstrapbase/bootstrap'], function($) {
    require(['theme_bootstrapbase/bootstrap'], function() {
        var target = $("#calendar-day-popover-link-1-2021-65-2");
        target.popover({
            content: function() {
                var source = target.next().find("> *:not('.hidden')");
                var content = $('<div>');

                if (source.length) {
                    content.html(source.clone(false));
                } else {
                    content.html(target.data('alternate'));
                }

                return content.html();
            }
        });
    });
});
;

require(['jquery', 'theme_bootstrapbase/bootstrap'], function($) {
    require(['theme_bootstrapbase/bootstrap'], function() {
        var target = $("#calendar-day-popover-link-1-2021-66-2");
        target.popover({
            content: function() {
                var source = target.next().find("> *:not('.hidden')");
                var content = $('<div>');

                if (source.length) {
                    content.html(source.clone(false));
                } else {
                    content.html(target.data('alternate'));
                }

                return content.html();
            }
        });
    });
});
;

require(['jquery', 'theme_bootstrapbase/bootstrap'], function($) {
    require(['theme_bootstrapbase/bootstrap'], function() {
        var target = $("#calendar-day-popover-link-1-2021-69-2");
        target.popover({
            content: function() {
                var source = target.next().find("> *:not('.hidden')");
                var content = $('<div>');

                if (source.length) {
                    content.html(source.clone(false));
                } else {
                    content.html(target.data('alternate'));
                }

                return content.html();
            }
        });
    });
});
;

require(['jquery', 'theme_bootstrapbase/bootstrap'], function($) {
    require(['theme_bootstrapbase/bootstrap'], function() {
        var target = $("#calendar-day-popover-link-1-2021-70-2");
        target.popover({
            content: function() {
                var source = target.next().find("> *:not('.hidden')");
                var content = $('<div>');

                if (source.length) {
                    content.html(source.clone(false));
                } else {
                    content.html(target.data('alternate'));
                }

                return content.html();
            }
        });
    });
});
;

require(['jquery', 'theme_bootstrapbase/bootstrap'], function($) {
    require(['theme_bootstrapbase/bootstrap'], function() {
        var target = $("#calendar-day-popover-link-1-2021-72-2");
        target.popover({
            content: function() {
                var source = target.next().find("> *:not('.hidden')");
                var content = $('<div>');

                if (source.length) {
                    content.html(source.clone(false));
                } else {
                    content.html(target.data('alternate'));
                }

                return content.html();
            }
        });
    });
});
;

require(['jquery', 'theme_bootstrapbase/bootstrap'], function($) {
    require(['theme_bootstrapbase/bootstrap'], function() {
        var target = $("#calendar-day-popover-link-1-2021-73-2");
        target.popover({
            content: function() {
                var source = target.next().find("> *:not('.hidden')");
                var content = $('<div>');

                if (source.length) {
                    content.html(source.clone(false));
                } else {
                    content.html(target.data('alternate'));
                }

                return content.html();
            }
        });
    });
});
;

require(['jquery', 'theme_bootstrapbase/bootstrap'], function($) {
    require(['theme_bootstrapbase/bootstrap'], function() {
        var target = $("#calendar-day-popover-link-1-2021-74-2");
        target.popover({
            content: function() {
                var source = target.next().find("> *:not('.hidden')");
                var content = $('<div>');

                if (source.length) {
                    content.html(source.clone(false));
                } else {
                    content.html(target.data('alternate'));
                }

                return content.html();
            }
        });
    });
});
;

require(['jquery', 'theme_bootstrapbase/bootstrap'], function($) {
    require(['theme_bootstrapbase/bootstrap'], function() {
        var target = $("#calendar-day-popover-link-1-2021-75-2");
        target.popover({
            content: function() {
                var source = target.next().find("> *:not('.hidden')");
                var content = $('<div>');

                if (source.length) {
                    content.html(source.clone(false));
                } else {
                    content.html(target.data('alternate'));
                }

                return content.html();
            }
        });
    });
});
;

require(['jquery', 'theme_bootstrapbase/bootstrap'], function($) {
    require(['theme_bootstrapbase/bootstrap'], function() {
        var target = $("#calendar-day-popover-link-1-2021-79-2");
        target.popover({
            content: function() {
                var source = target.next().find("> *:not('.hidden')");
                var content = $('<div>');

                if (source.length) {
                    content.html(source.clone(false));
                } else {
                    content.html(target.data('alternate'));
                }

                return content.html();
            }
        });
    });
});
;

require(['jquery', 'theme_bootstrapbase/bootstrap'], function($) {
    require(['theme_bootstrapbase/bootstrap'], function() {
        var target = $("#calendar-day-popover-link-1-2021-81-2");
        target.popover({
            content: function() {
                var source = target.next().find("> *:not('.hidden')");
                var content = $('<div>');

                if (source.length) {
                    content.html(source.clone(false));
                } else {
                    content.html(target.data('alternate'));
                }

                return content.html();
            }
        });
    });
});
;

require(['jquery', 'theme_bootstrapbase/bootstrap'], function($) {
    require(['theme_bootstrapbase/bootstrap'], function() {
        var target = $("#calendar-day-popover-link-1-2021-82-2");
        target.popover({
            content: function() {
                var source = target.next().find("> *:not('.hidden')");
                var content = $('<div>');

                if (source.length) {
                    content.html(source.clone(false));
                } else {
                    content.html(target.data('alternate'));
                }

                return content.html();
            }
        });
    });
});
;

require(['jquery', 'theme_bootstrapbase/bootstrap'], function($) {
    require(['theme_bootstrapbase/bootstrap'], function() {
        var target = $("#calendar-day-popover-link-1-2021-83-2");
        target.popover({
            content: function() {
                var source = target.next().find("> *:not('.hidden')");
                var content = $('<div>');

                if (source.length) {
                    content.html(source.clone(false));
                } else {
                    content.html(target.data('alternate'));
                }

                return content.html();
            }
        });
    });
});
;

require(['jquery', 'theme_bootstrapbase/bootstrap'], function($) {
    require(['theme_bootstrapbase/bootstrap'], function() {
        var target = $("#calendar-day-popover-link-1-2021-84-2");
        target.popover({
            content: function() {
                var source = target.next().find("> *:not('.hidden')");
                var content = $('<div>');

                if (source.length) {
                    content.html(source.clone(false));
                } else {
                    content.html(target.data('alternate'));
                }

                return content.html();
            }
        });
    });
});
;

require(['jquery', 'theme_bootstrapbase/bootstrap'], function($) {
    require(['theme_bootstrapbase/bootstrap'], function() {
        var target = $("#calendar-day-popover-link-1-2021-86-2");
        target.popover({
            content: function() {
                var source = target.next().find("> *:not('.hidden')");
                var content = $('<div>');

                if (source.length) {
                    content.html(source.clone(false));
                } else {
                    content.html(target.data('alternate'));
                }

                return content.html();
            }
        });
    });
});
;

require([
    'jquery',
    'core_calendar/selectors',
    'core_calendar/events',
], function(
    $,
    CalendarSelectors,
    CalendarEvents
) {

    $('body').on(CalendarEvents.filterChanged, function(e, data) {
        M.util.js_pending("month-mini-2-filterChanged");
        // A filter value has been changed.
        // Find all matching cells in the popover data, and hide them.
        $("#month-mini-2021-March-2")
            .find(CalendarSelectors.popoverType[data.type])
            .toggleClass('hidden', !!data.hidden);
        M.util.js_complete("month-mini-2-filterChanged");
    });
});
</script></head>

<body id="page-site-index" class="format-site course path-site safari dir-ltr lang-es yui-skin-sam yui3-skin-sam gracia-sallenet-org pagelayout-frontpage course-1 context-2 loggedin desktopdevice pagewidthvariable custommenuitems categoryicons hasboringlayout floatingsubmit has-region-side-pre used-region-side-pre has-region-footer-left empty-region-footer-left has-region-footer-middle empty-region-footer-middle has-region-footer-right empty-region-footer-right has-region-hidden-dock used-region-hidden-dock has-region-page-top used-region-page-top has-region-header empty-region-header jsenabled"><div id="MathJax_Message" style="display: none;"></div>

<div class="skiplinks">
    <a href="#maincontent" class="skip">Salta al contenido principal</a>
</div><script type="text/javascript" src="https://gracia.sallenet.org/theme/yui_combo.php?rollup/3.17.2/yui-moodlesimple-min.js"></script><div id="yui3-css-stamp" style="position: absolute !important; visibility: hidden !important" class=""></div><script type="text/javascript" src="https://gracia.sallenet.org/lib/javascript.php/1614308938/lib/javascript-static.js"></script>
<script type="text/javascript">
//<![CDATA[
document.body.className += ' jsenabled';
//]]>
</script>


<header role="banner">
    <nav id="essentialnavbar" role="navigation" class="moodle-has-zindex logo">
        <div class="navbar">
            <div class="container-fluid navbar-inner">
                <div class="row-fluid">
                    <div class="custommenus pull-left">
                        <a class="btn btn-navbar" data-toggle="collapse" data-target="#essentialmenus">
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </a>
                        <a class="brand" href="https://gracia.sallenet.org/">Sallenet</a>                    <div class="pull-right">
                        <div class="usermenu navbarrightitem">
                            <ul class="nav"><li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="https://gracia.sallenet.org/"><img src="https://gracia.sallenet.org/pluginfile.php/159307/user/icon/essential/f1?rev=4844747" class="userpicture" width="72" height="72" alt="Imagen de Triay España, Jaume Josep" title="Imagen de Triay España, Jaume Josep">Jaume Josep<span aria-hidden="true" class="fa fa-caret-right"></span></a><ul class="dropdown-menu pull-right"><li><a href="https://gracia.sallenet.org/user/profile.php?id=6315"><em><span aria-hidden="true" class="fa fa-user"></span>Jaume Josep Triay España</em></a></li><li class="dropdown-submenu preferences"><a class="dropdown-toggle" data-toggle="dropdown" href="https://gracia.sallenet.org/"><em><span aria-hidden="true" class="fa fa-cog"></span>Preferencias</em></a><ul class="dropdown-menu"><li><a href="https://gracia.sallenet.org/user/preferences.php?userid=6315"><em><span aria-hidden="true" class="fa fa-user"></span>Usuario</em></a></li><li><a href="https://gracia.sallenet.org/login/change_password.php"><em><span aria-hidden="true" class="fa fa-key"></span>Cambiar contraseña</em></a></li><li><a href="https://gracia.sallenet.org/blog/preferences.php"><em><span aria-hidden="true" class="fa fa-rss-square"></span>Blog</em></a></li><li><a href="https://gracia.sallenet.org/badges/preferences.php"><em><span aria-hidden="true" class="fa fa-certificate"></span>Insignia</em></a></li></ul></li><hr class="sep"><li><a href="https://gracia.sallenet.org/calendar/view.php"><em><span aria-hidden="true" class="fa fa-calendar"></span>Calendario</em></a></li><li><a href="https://gracia.sallenet.org/message/index.php"><em><span aria-hidden="true" class="fa fa-envelope"></span>Mensajes</em></a></li><li><a href="https://gracia.sallenet.org/user/files.php"><em><span aria-hidden="true" class="fa fa-file"></span>Archivos privados</em></a></li><li><a href="https://gracia.sallenet.org/mod/forum/user.php?id=6315"><em><span aria-hidden="true" class="fa fa-list-alt"></span>Mensajes en foros</em></a></li><li><a href="https://gracia.sallenet.org/mod/forum/user.php?id=6315&amp;mode=discussions"><em><span aria-hidden="true" class="fa fa-list"></span>Debates</em></a></li><hr class="sep"><li><a href="https://gracia.sallenet.org/grade/report/overview/index.php?userid=6315"><em><span aria-hidden="true" class="fa fa-list-alt"></span>Mis calificaciones</em></a></li><li><a href="https://gracia.sallenet.org/badges/mybadges.php"><em><span aria-hidden="true" class="fa fa-certificate"></span>Insignias</em></a></li><hr class="sep"><li><a href="https://gracia.sallenet.org/login/logout.php?sesskey=ZEdKpbZezO"><em><span aria-hidden="true" class="fa fa-sign-out"></span>Cerrar sesión</em></a></li></ul></li></ul>                        </div>
                        <div class="messagemenu navbarrightitem">
                            <div class="popover-region collapsed popover-region-messages" id="nav-message-popover-container" data-userid="6315" data-region="popover-region">
    <div class="popover-region-toggle nav-link" data-region="popover-region-toggle" role="button" aria-controls="popover-region-container-605df8a0a6ebf605df8a0905e24" aria-haspopup="true" aria-label="Mostrar la ventana de mensajes cuando no hay mensajes nuevos" tabindex="0">
                <i class="icon fa fa-comment fa-fw " title="Mostrar/ocultar menú de mensajes" aria-label="Mostrar/ocultar menú de mensajes"></i>
        <div class="count-container " data-region="count-container">3</div>

    </div>
    <div id="popover-region-container-605df8a0a6ebf605df8a0905e24" class="popover-region-container" data-region="popover-region-container" aria-expanded="false" aria-hidden="true" aria-label="Ventana de notificación" role="region">
        <div class="popover-region-header-container">
            <h3 class="popover-region-header-text" data-region="popover-region-header-text">Mensajes</h3>
            <div class="popover-region-header-actions" data-region="popover-region-header-actions">        <div class="newmessage-link">
            <a href="https://gracia.sallenet.org/mod/sallenet/modulos/comunicaciones/index.php?menu=MSG_REDACTAR">Nuevo mensaje
            </a>
        </div>
        <a class="mark-all-read-button" href="#" role="button" title="Marcar como leído" data-action="mark-all-read">
            <span class="normal-icon"><i class="icon fa fa-check fa-fw " title="Marcar como leído" aria-label="Marcar como leído"></i></span>
            <span class="loading-icon"><i class="icon fa fa-circle-o-notch fa-spin fa-fw " title="Enviando" aria-label="Enviando"></i></span>
        </a>
</div>
        </div>
        <div class="popover-region-content-container" data-region="popover-region-content-container">
            <div class="popover-region-content" data-region="popover-region-content">
                        <div class="messages" data-region="messages" role="log" aria-busy="false" aria-atomic="false" aria-relevant="additions"></div>
        <div class="empty-message" data-region="empty-message" tabindex="0">No hay mensajes</div>

            </div>
            <span class="loading-icon"><i class="icon fa fa-circle-o-notch fa-spin fa-fw " title="Enviando" aria-label="Enviando"></i></span>
        </div>
                <a class="see-all-link" target="_blank" href="https://gracia.sallenet.org/mod/sallenet/modulos/comunicaciones/index.php?menu=COM_MENSAJES">
                    <div class="popover-region-footer-container">
                        <div class="popover-region-seeall-text">Ver todo</div>
                    </div>
                </a>
    </div>
</div><div class="popover-region collapsed popover-region-notifications" id="nav-notification-popover-container" data-userid="6315" data-region="popover-region">
    <div class="popover-region-toggle nav-link" data-region="popover-region-toggle" role="button" aria-controls="popover-region-container-605df8a0a825d605df8a0905e25" aria-haspopup="true" aria-label="Mostrar la ventana de notificaciones cuando no hay ninguna" tabindex="0">
                <i class="icon fa fa-bell fa-fw " title="Mostrar/ocultar menú de notificaciones" aria-label="Mostrar/ocultar menú de notificaciones"></i>
        <div class="count-container hidden" data-region="count-container">0</div>

    </div>
    <div id="popover-region-container-605df8a0a825d605df8a0905e25" class="popover-region-container" data-region="popover-region-container" aria-expanded="false" aria-hidden="true" aria-label="Ventana de notificación" role="region">
        <div class="popover-region-header-container">
            <h3 class="popover-region-header-text" data-region="popover-region-header-text">Notificaciones</h3>
            <div class="popover-region-header-actions" data-region="popover-region-header-actions">        <a class="mark-all-read-button" href="#" title="Marcar como leído" data-action="mark-all-read" role="button">
            <span class="normal-icon"><i class="icon fa fa-check fa-fw " title="Marcar como leído" aria-label="Marcar como leído"></i></span>
            <span class="loading-icon"><i class="icon fa fa-circle-o-notch fa-spin fa-fw " title="Enviando" aria-label="Enviando"></i></span>
        </a>
</div>
        </div>
        <div class="popover-region-content-container" data-region="popover-region-content-container">
            <div class="popover-region-content" data-region="popover-region-content">
                        <div class="all-notifications" data-region="all-notifications" role="log" aria-busy="false" aria-atomic="false" aria-relevant="additions"></div>
        <div class="empty-message" tabindex="0" data-region="empty-message">No tienes notificaciones</div>

            </div>
            <span class="loading-icon"><i class="icon fa fa-circle-o-notch fa-spin fa-fw " title="Enviando" aria-label="Enviando"></i></span>
        </div>
                <a class="see-all-link" target="_blank" href="https://gracia.sallenet.org/mod/sallenet/modulos/comunicaciones/index.php?menu=MSG_BANDEJA&amp;menu_seleccionado=2">
                    <div class="popover-region-footer-container">
                        <div class="popover-region-seeall-text">Ver todo</div>
                    </div>
                </a>
    </div>
</div>                        </div>
                        <div class="navbarrightitem">
                                                    </div>
                                                                        <div id="custom_menu_editing" class="navbarrightitem">
                                                    </div>
                        <div class="navbarrightitem">
                                                    </div>
                    </div>
                        <div id="essentialmenus" class="nav-collapse collapse pull-left">
                            <div id="custom_menu_language" class="custom_menu"><ul class="nav"><li class="dropdown langmenu"><a href="https://gracia.sallenet.org/" class="dropdown-toggle" data-toggle="dropdown" title="Idioma"><span aria-hidden="true" class="fa fa-flag"></span>Español - Internacional ?(es)?<span aria-hidden="true" class="fa fa-caret-right"></span></a><div class="dropdown-menu"><ul><li><a title="Català ?(ca)?" href="https://gracia.sallenet.org/?lang=ca"><span aria-hidden="true" class="fa fa-language"></span>Català ?(ca)?</a></li><li><a title="English ?(en)?" href="https://gracia.sallenet.org/?lang=en"><span aria-hidden="true" class="fa fa-language"></span>English ?(en)?</a></li><li><a title="Español - Internacional ?(es)?" href="https://gracia.sallenet.org/?lang=es"><span aria-hidden="true" class="fa fa-language"></span>Español - Internacional ?(es)?</a></li></ul></div></li></ul></div><div id="custom_menu_courses" class="custom_menu"><ul class="nav"><li class="dropdown"><a href="https://gracia.sallenet.org/" class="dropdown-toggle" data-toggle="dropdown" title="Mis cursos"><span aria-hidden="true" class="fa fa-briefcase"></span>Mis cursos<span aria-hidden="true" class="fa fa-caret-right"></span></a><div class="dropdown-menu"><ul><li><a title="Área personal" href="https://gracia.sallenet.org/my/index.php"><span><span aria-hidden="true" class="fa fa-home"></span><span> Área personal</span></span></a></li><li><a title="20-21) M12: Empresa i iniciativa emprenedora-DAM1A-M12" href="https://gracia.sallenet.org/course/view.php?id=8231"><span><span aria-hidden="true" class="fa fa-graduation-cap"></span>20-21) M12: Empresa i iniciativa emprenedora-DAM1A</span></a></li><li><a title="20-21) M12-UF1: Empresa i iniciativa emprenedora-DAM1A-M12-UF1" href="https://gracia.sallenet.org/course/view.php?id=8230"><span><span aria-hidden="true" class="fa fa-graduation-cap"></span>20-21) M12-UF1: Empresa i iniciativa emprenedora-DAM1A</span></a></li><li><a title="20-21) M03-UF2: Disseny modular-DAM1-M03-UF2" href="https://gracia.sallenet.org/course/view.php?id=8216"><span><span aria-hidden="true" class="fa fa-graduation-cap"></span>20-21) M03-UF2: Disseny modular-DAM1</span></a></li><li><a title="20-21) M02: Bases de dades-DAM1A-M02" href="https://gracia.sallenet.org/course/view.php?id=8214"><span><span aria-hidden="true" class="fa fa-graduation-cap"></span>20-21) M02: Bases de dades-DAM1A</span></a></li><li><a title="20-21) M02-UF3: Llenguatge SQL: DCL i extensió procedimental-DAM1A-M02-UF3" href="https://gracia.sallenet.org/course/view.php?id=8212"><span><span aria-hidden="true" class="fa fa-graduation-cap"></span>20-21) M02-UF3: Llenguatge SQL: DCL i extensió procedimental-DAM1A</span></a></li><li><a title="20-21) M05: Entorns de desenvolupament-DAM2-M05" href="https://gracia.sallenet.org/course/view.php?id=8585"><span><span aria-hidden="true" class="fa fa-graduation-cap"></span>20-21) M05: Entorns de desenvolupament-DAM2</span></a></li><li><a title="20-21) M05-UF3: Introducció al disseny orientat a objectes-DAM2-M05-UF3" href="https://gracia.sallenet.org/course/view.php?id=8584"><span><span aria-hidden="true" class="fa fa-graduation-cap"></span>20-21) M05-UF3: Introducció al disseny orientat a objectes-DAM2</span></a></li><li><a title="20-21) M05-UF2: Optimització del programari-DAM2-M05-UF2" href="https://gracia.sallenet.org/course/view.php?id=8583"><span><span aria-hidden="true" class="fa fa-graduation-cap"></span>20-21) M05-UF2: Optimització del programari-DAM2</span></a></li><li><a title="20-21) M05-UF1: Desenvolupament de programari-DAM2-M05-UF1" href="https://gracia.sallenet.org/course/view.php?id=8582"><span><span aria-hidden="true" class="fa fa-graduation-cap"></span>20-21) M05-UF1: Desenvolupament de programari-DAM2</span></a></li><li><a title="20-21) M03: Programació-DAM2-M03" href="https://gracia.sallenet.org/course/view.php?id=8581"><span><span aria-hidden="true" class="fa fa-graduation-cap"></span>20-21) M03: Programació-DAM2</span></a></li><li><a title="20-21) M03-UF6: POO. Introducció a la persistència en BD-DAM2-M03-UF6" href="https://gracia.sallenet.org/course/view.php?id=8580"><span><span aria-hidden="true" class="fa fa-graduation-cap"></span>20-21) M03-UF6: POO. Introducció a la persistència en BD-DAM2</span></a></li><li><a title="20-21) M03-UF5: POO. Llibreries de classes fonamentals-DAM2-M03-UF5" href="https://gracia.sallenet.org/course/view.php?id=8579"><span><span aria-hidden="true" class="fa fa-graduation-cap"></span>20-21) M03-UF5: POO. Llibreries de classes fonamentals-DAM2</span></a></li><li><a title="20-21) M03-UF4: Programació orientada a objectes. Fonaments-DAM2-M03-UF4" href="https://gracia.sallenet.org/course/view.php?id=8578"><span><span aria-hidden="true" class="fa fa-graduation-cap"></span>20-21) M03-UF4: Programació orientada a objectes. Fonaments-DAM2</span></a></li><li><a title="20-21) M14: Formació en centres de treball-DAM2-M14" href="https://gracia.sallenet.org/course/view.php?id=8278"><span><span aria-hidden="true" class="fa fa-graduation-cap"></span>20-21) M14: Formació en centres de treball-DAM2</span></a></li><li><a title="20-21) M14-UF1: Formació en centres de treball-DAM2-M14-UF1" href="https://gracia.sallenet.org/course/view.php?id=8277"><span><span aria-hidden="true" class="fa fa-graduation-cap"></span>20-21) M14-UF1: Formació en centres de treball-DAM2</span></a></li><li><a title="20-21) M13: Projecte de  desenvolupament  d’aplicacions multiplataforma-DAM2-M13" href="https://gracia.sallenet.org/course/view.php?id=8276"><span><span aria-hidden="true" class="fa fa-graduation-cap"></span>20-21) M13: Projecte de  desenvolupament  d’aplicacions multiplataforma-DAM2</span></a></li><li><a title="20-21) M13-UF1: Projecte de desenvolupament d`aplicacions multiplataforma-DAM2-M13-UF1" href="https://gracia.sallenet.org/course/view.php?id=8275"><span><span aria-hidden="true" class="fa fa-graduation-cap"></span>20-21) M13-UF1: Projecte de desenvolupament d`aplicacions multiplataforma-DAM2</span></a></li><li><a title="20-21) M10: Sistemes de gestió  empresarial-DAM2-M10" href="https://gracia.sallenet.org/course/view.php?id=8274"><span><span aria-hidden="true" class="fa fa-graduation-cap"></span>20-21) M10: Sistemes de gestió  empresarial-DAM2</span></a></li><li><a title="20-21) M10-UF2: Sistemes ERP-CRM. Explotació i adequació.-DAM2-M10-UF2" href="https://gracia.sallenet.org/course/view.php?id=8273"><span><span aria-hidden="true" class="fa fa-graduation-cap"></span>20-21) M10-UF2: Sistemes ERP-CRM. Explotació i adequació.-DAM2</span></a></li><li><a title="20-21) M10-UF1: Sistemes ERP-CRM. Implantació.-DAM2-M10-UF1" href="https://gracia.sallenet.org/course/view.php?id=8272"><span><span aria-hidden="true" class="fa fa-graduation-cap"></span>20-21) M10-UF1: Sistemes ERP-CRM. Implantació.-DAM2</span></a></li><li><a title="20-21) M09: Programació de serveis  i processos-DAM2-M09" href="https://gracia.sallenet.org/course/view.php?id=8271"><span><span aria-hidden="true" class="fa fa-graduation-cap"></span>20-21) M09: Programació de serveis  i processos-DAM2</span></a></li><li><a title="20-21) M09-UF3: Sòcols i serveis-DAM2-M09-UF3" href="https://gracia.sallenet.org/course/view.php?id=8270"><span><span aria-hidden="true" class="fa fa-graduation-cap"></span>20-21) M09-UF3: Sòcols i serveis-DAM2</span></a></li><li><a title="20-21) M09-UF2: Processos i fils-DAM2-M09-UF2" href="https://gracia.sallenet.org/course/view.php?id=8269"><span><span aria-hidden="true" class="fa fa-graduation-cap"></span>20-21) M09-UF2: Processos i fils-DAM2</span></a></li><li><a title="20-21) M09-UF1: Seguretat i criptografia-DAM2-M09-UF1" href="https://gracia.sallenet.org/course/view.php?id=8268"><span><span aria-hidden="true" class="fa fa-graduation-cap"></span>20-21) M09-UF1: Seguretat i criptografia-DAM2</span></a></li><li><a title="20-21) M08: Programació multimèdia  i dispositius mòbils-DAM2-M08" href="https://gracia.sallenet.org/course/view.php?id=8267"><span><span aria-hidden="true" class="fa fa-graduation-cap"></span>20-21) M08: Programació multimèdia  i dispositius mòbils-DAM2</span></a></li><li><a title="20-21) M08-UF3: Desenvolupament de jocs per dispositius mòbils-DAM2-M08-UF3" href="https://gracia.sallenet.org/course/view.php?id=8266"><span><span aria-hidden="true" class="fa fa-graduation-cap"></span>20-21) M08-UF3: Desenvolupament de jocs per dispositius mòbils-DAM2</span></a></li><li><a title="20-21) M08-UF2: Programació multimèdia-DAM2-M08-UF2" href="https://gracia.sallenet.org/course/view.php?id=8265"><span><span aria-hidden="true" class="fa fa-graduation-cap"></span>20-21) M08-UF2: Programació multimèdia-DAM2</span></a></li><li><a title="20-21) M08-UF1: Desenvolupament d`aplicacions per dispositius mòbils-DAM2-M08-UF1" href="https://gracia.sallenet.org/course/view.php?id=8264"><span><span aria-hidden="true" class="fa fa-graduation-cap"></span>20-21) M08-UF1: Desenvolupament d`aplicacions per dispositius mòbils-DAM2</span></a></li><li><a title="20-21) M07: Desenvolupament  d’interfícies-DAM2-M07" href="https://gracia.sallenet.org/course/view.php?id=8263"><span><span aria-hidden="true" class="fa fa-graduation-cap"></span>20-21) M07: Desenvolupament  d’interfícies-DAM2</span></a></li><li><a title="20-21) M07-UF2: Preparació i distribució d`aplicacions-DAM2-M07-UF2" href="https://gracia.sallenet.org/course/view.php?id=8262"><span><span aria-hidden="true" class="fa fa-graduation-cap"></span>20-21) M07-UF2: Preparació i distribució d`aplicacions-DAM2</span></a></li><li><a title="20-21) M07-UF1: Disseny i implementació d`interfícies-DAM2-M07-UF1" href="https://gracia.sallenet.org/course/view.php?id=8261"><span><span aria-hidden="true" class="fa fa-graduation-cap"></span>20-21) M07-UF1: Disseny i implementació d`interfícies-DAM2</span></a></li><li><a title="20-21) M06: Accés a dades-DAM2-M06" href="https://gracia.sallenet.org/course/view.php?id=8260"><span><span aria-hidden="true" class="fa fa-graduation-cap"></span>20-21) M06: Accés a dades-DAM2</span></a></li><li><a title="20-21) M06-UF4: Components d'accés a dades-DAM2-M06-UF4" href="https://gracia.sallenet.org/course/view.php?id=8259"><span><span aria-hidden="true" class="fa fa-graduation-cap"></span>20-21) M06-UF4: Components d'accés a dades-DAM2</span></a></li><li><a title="20-21) M06-UF3: Persistència en BD natives XML-DAM2-M06-UF3" href="https://gracia.sallenet.org/course/view.php?id=8258"><span><span aria-hidden="true" class="fa fa-graduation-cap"></span>20-21) M06-UF3: Persistència en BD natives XML-DAM2</span></a></li><li><a title="20-21) M06-UF2: Persistència en BDR-BDOR-BDOO-DAM2-M06-UF2" href="https://gracia.sallenet.org/course/view.php?id=8257"><span><span aria-hidden="true" class="fa fa-graduation-cap"></span>20-21) M06-UF2: Persistència en BDR-BDOR-BDOO-DAM2</span></a></li><li><a title="20-21) M06-UF1: Persistència en fitxers-DAM2-M06-UF1" href="https://gracia.sallenet.org/course/view.php?id=8256"><span><span aria-hidden="true" class="fa fa-graduation-cap"></span>20-21) M06-UF1: Persistència en fitxers-DAM2</span></a></li><li><a title="TUT 2020-2021 CFS2B - DAM2 - A" href="https://gracia.sallenet.org/course/view.php?id=8255"><span><span aria-hidden="true" class="fa fa-graduation-cap"></span>20-21) Tutoría - CFS2B - DAM2 - A</span></a></li></ul></div></li></ul></div><div id="custom_menu" class="custom_menu"><ul class="nav"><li><a title="WEB" href="http://www.lasallegracia.cat/">WEB</a></li><li><a title="CORREU" href="http://www.outlook.com/lasalle.cat">CORREU</a></li><li><a title="REFLEXIÓ" href="http://reflexiondeldia.eu/ca" target="_blank">REFLEXIÓ</a></li></ul></div>                        </div>
                    </div>
                </div>
            </div>
        </div>
    </nav>
    <div id="page-header" class="clearfix logo" style="margin-top: 40.1333px;">
        <div class="container-fluid">
            <div class="row-fluid">
<div class="pull-left logo-container"><a class="logo" href="//gracia.sallenet.org" title="Página Principal"><img src="//gracia.sallenet.org/pluginfile.php/1/theme_essential/logo/1614308938/logocole.png" class="img-responsive" alt="Página Principal"></a>                </div>
                                <a class="btn btn-icon collapsed" data-toggle="collapse" data-target="#essentialicons">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </a>

                <div id="essentialicons" class="collapse pull-right">
                        <div class="pull-right" id="socialnetworks">
                            <p class="socialheading">Redes sociales</p>
                            <ul class="socials unstyled">
                                <li><button type="button" class="socialicon twitter" onclick="window.open('https://www.twitter.com/')" title="URL de Twitter" aria-label="URL de Twitter"><span aria-hidden="true" class="fa fa-twitter"></span><span class="sr-only"></span></button></li><li><button type="button" class="socialicon facebook" onclick="window.open('https://www.facebook.com/SalleGracia')" title="URL de Facebook" aria-label="URL de Facebook"><span aria-hidden="true" class="fa fa-facebook"></span><span class="sr-only"></span></button></li><li><button type="button" class="socialicon youtube" onclick="window.open('https://www.youtube.es')" title="URL de YouTube" aria-label="URL de YouTube"><span aria-hidden="true" class="fa fa-youtube"></span><span class="sr-only"></span></button></li><li><button type="button" class="socialicon flickr" onclick="window.open('http://www.flickr.com/')" title="URL de Flickr" aria-label="URL de Flickr"><span aria-hidden="true" class="fa fa-flickr"></span><span class="sr-only"></span></button></li><li><button type="button" class="socialicon website" onclick="window.open('http://www.lasalle.es')" title="URL de la Página" aria-label="URL de la Página"><span aria-hidden="true" class="fa fa-globe"></span><span class="sr-only"></span></button></li>                            </ul>
                        </div>
                                            <div class="pull-right" id="mobileapps">
                            <p class="socialheading">Apps</p>
                            <ul class="socials unstyled">
                                <li><button type="button" class="socialicon ios" onclick="window.open('https://itunes.apple.com/us/app/sallenet-app/id1076643256?ls=1&amp;mt=8')" title="iPhone/iPad (App Store)" aria-label="iPhone/iPad (App Store)"><span aria-hidden="true" class="fa fa-apple"></span><span class="sr-only"></span></button></li><li><button type="button" class="socialicon android" onclick="window.open('https://play.google.com/store/apps/details?id=org.sallenet.app')" title="Android (Google Play)" aria-label="Android (Google Play)"><span aria-hidden="true" class="fa fa-android"></span><span class="sr-only"></span></button></li>                            </ul>
                        </div>
                                    </div>
            </div>
        </div>
    </div>
</header>
<div id="page" class="container-fluid">
        <section class="slideshow">
        <!-- Start Slideshow -->
                <!-- End Slideshow -->
    </section>

    <section id="yui_3_17_2_1_1616771229552_239">
        <!-- Start Main Regions -->

        <!-- Start Alerts -->

        <!-- Alert #1 -->
        
        <!-- Alert #2 -->
        
        <!-- Alert #3 -->
                <!-- End Alerts -->

        <!-- Start Frontpage Content -->
                <!-- End Frontpage Content -->

        <!-- Start Marketing Spots -->
        <!-- End Marketing Spots -->

<!-- Start Header blocks was Middle blocks -->
<!-- End Header blocks was Middle blocks -->

        <div id="page-content" class="row-fluid">
            <section id="main-and-pre">
<div id="content" class="span9 pull-right"><aside id="block-region-page-top" class="row-fluid block-region rowblock-blocks" data-blockregion="page-top" data-droptarget="1"><div class="row-fluid" id="yui_3_17_2_1_1616771229552_238"><a class="skip skip-block" id="fsb-10" href="#sb-10">Salta Sallenet) Mi Sallenet</a><div id="inst19" class="block_sn_my_sallenet block list_block span4" role="complementary" data-block="sn_my_sallenet" data-instanceid="19" aria-labelledby="instance-19-header" data-dockable="1"><div class="header"><div class="title" id="yui_3_17_2_1_1616771229552_62"><div class="block_action"><i class="block-hider-hide icon fa fa-minus-square-o fa-fw" aria-hidden="true" aria-label="Oculta bloque Sallenet) Mi Sallenet" tabindex="0" title="Oculta bloque Sallenet) Mi Sallenet"></i><i class="block-hider-show icon fa fa-plus-square-o fa-fw" aria-hidden="true" aria-label="Muestra bloque Sallenet) Mi Sallenet" tabindex="0" title="Muestra bloque Sallenet) Mi Sallenet"></i><input type="image" class="moveto customcommand requiresjs" alt="Minimizar en la barra lateral" title="Acoplar bloque Sallenet) Mi Sallenet" src="https://gracia.sallenet.org/theme/image.php/essential/core/1614308938/t/block_to_dock"></div><span aria-hidden="true" class="fa fa-navicon"></span><h2 id="instance-19-header">Sallenet) Mi Sallenet</h2></div></div><div class="content"><ul class="unlist"><li class="r0"><div class="icon column c0">











<a href="<?php echo e(url('alumno')); ?>"><img src="https://gracia.sallenet.org/mod/sallenet/img/alumnos.png" alt="" title="Alumnos" width="30px"></a>
<a href="<?php echo e(url('alumno')); ?>">Alumnos</a></div><div class="column c1"></div></li>















<li class="r1"><div class="icon column c0"><a href="https://gracia.sallenet.org/mod/sallenet/modulos/comunicaciones/">
<img src="https://gracia.sallenet.org/mod/sallenet/img/comunicaciones.png" width="30px"></a>
<a href="https://gracia.sallenet.org/mod/sallenet/modulos/comunicaciones/">Comunicaciones</a></div><div class="column c1"></div></li></ul></div></div><span class="skip-block-to" id="sb-10"></span><a class="skip skip-block" id="fsb-11" href="#sb-11">Salta Calendario</a><div id="inst3" class="block_calendar_month block span4" role="complementary" data-block="calendar_month" data-instanceid="3" aria-labelledby="instance-3-header" data-dockable="1"><div class="header"><div class="title" id="yui_3_17_2_1_1616771229552_78"><div class="block_action"><i class="block-hider-hide icon fa fa-minus-square-o fa-fw" aria-hidden="true" aria-label="Oculta bloque Calendario" tabindex="0" title="Oculta bloque Calendario"></i><i class="block-hider-show icon fa fa-plus-square-o fa-fw" aria-hidden="true" aria-label="Muestra bloque Calendario" tabindex="0" title="Muestra bloque Calendario"></i><input type="image" class="moveto customcommand requiresjs" alt="Minimizar en la barra lateral" title="Acoplar bloque Calendario" src="https://gracia.sallenet.org/theme/image.php/essential/core/1614308938/t/block_to_dock"></div><span aria-hidden="true" class="fa fa-calendar"></span><h2 id="instance-3-header">Calendario</h2></div></div><div class="content"><div id="calendar-month-2021-March-605df8a09f011605df8a0905e22" data-template="core_calendar/month_mini" data-includenavigation="true" data-mini="true">
    <div id="month-mini-2021-March-2" class="calendarwrapper" data-courseid="1" data-categoryid="0" data-month="3" data-year="2021" data-view="month">


<span class="overlay-icon-container hidden" data-region="overlay-icon-container">


<span class="loading-icon"><i class="icon fa fa-circle-o-notch fa-spin fa-fw " title="Enviando" aria-label="Enviando"></i></span>
</span>
    <table class="minicalendar calendartable">
        <caption class="calendar-controls">
                <a href="#" class="arrow_link previous" title="Mes anterior" data-year="2021" data-month="2">
                    <span class="arrow">?</span>
                </a>
                <span class="hide"> | </span>
                <span class="current">
                    <a href="https://gracia.sallenet.org/calendar/view.php?view=month&amp;time=1614553200" title="Este mes">marzo 2021</a>
                </span>
                <span class="hide"> | </span>
                <a href="#" class="arrow_link next" title="Mes próximo" data-year="2021" data-month="4">
                    <span class="arrow">?</span>
                </a>
        </caption>
        <thead>
          <tr>
                <th class="header text-xs-center" scope="col">
                    <abbr title="Lunes">Lun</abbr>
                </th>
                <th class="header text-xs-center" scope="col">
                    <abbr title="Martes">Mar</abbr>
                </th>
                <th class="header text-xs-center" scope="col">
                    <abbr title="Miércoles">Mié</abbr>
                </th>
                <th class="header text-xs-center" scope="col">
                    <abbr title="Jueves">Jue</abbr>
                </th>
                <th class="header text-xs-center" scope="col">
                    <abbr title="Viernes">Vie</abbr>
                </th>
                <th class="header text-xs-center" scope="col">
                    <abbr title="Sábado">Sáb</abbr>
                </th>
                <th class="header text-xs-center" scope="col">
                    <abbr title="Domingo">Dom</abbr>
                </th>
            </tr>
        </thead>
        <tbody>
            <tr data-region="month-view-week">
                    <td class="day text-center hasevent calendar_event_course duration_finish" data-eventtype-course="1" data-day-timestamp="1614553200">


<a href="https://gracia.sallenet.org/calendar/view.php?view=day&amp;time=1614553200" id="calendar-day-popover-link-1-2021-59-2" data-container="body" data-toggle="popover" data-html="true" data-trigger="hover" data-placement="top" data-title="lunes, 1 marzo eventos" data-alternate="No hay eventos" data-original-title="" title="">1</a>
<div class="hidden">

                                        <div data-popover-eventtype-course="1">
                                                <img class="icon " src="https://gracia.sallenet.org/theme/image.php/essential/assign/1614308938/icon" alt="" title="">
                                            20-21) M06-UF2: Persistència en BDR-BDOR-BDOO-DAM2-M06-UF2: Examen UF2 - Grup Vermell pendiente
                                        </div>
                                        <div data-popover-eventtype-course="1">
                                                <img class="icon " src="https://gracia.sallenet.org/theme/image.php/essential/assign/1614308938/icon" alt="" title="">
                                            20-21) M03-UF2: Disseny modular-DAM1-M03-UF2: POU03 - Crea la classe Persona pendiente
                                        </div>
                                </div>
</td>
                    <td class="day text-center hasevent calendar_event_course duration_finish" data-eventtype-course="1" data-day-timestamp="1614639600">


<a href="https://gracia.sallenet.org/calendar/view.php?view=day&amp;time=1614639600" id="calendar-day-popover-link-1-2021-60-2" data-container="body" data-toggle="popover" data-html="true" data-trigger="hover" data-placement="top" data-title="martes, 2 marzo eventos" data-alternate="No hay eventos" data-original-title="" title="">2</a>
<div class="hidden">

                                        <div data-popover-eventtype-course="1">
                                                <img class="icon " src="https://gracia.sallenet.org/theme/image.php/essential/assign/1614308938/icon" alt="" title="">
                                            20-21) M06-UF2: Persistència en BDR-BDOR-BDOO-DAM2-M06-UF2: Examen UF2 - Grup Blau pendiente
                                        </div>
                                </div>
</td>
                    <td class="day text-center" data-day-timestamp="1614726000">                            3
                        </td>
                    <td class="day text-center hasevent calendar_event_course duration_finish" data-eventtype-course="1" data-day-timestamp="1614812400">


<a href="https://gracia.sallenet.org/calendar/view.php?view=day&amp;time=1614812400" id="calendar-day-popover-link-1-2021-62-2" data-container="body" data-toggle="popover" data-html="true" data-trigger="hover" data-placement="top" data-title="jueves, 4 marzo eventos" data-alternate="No hay eventos" data-original-title="" title="">4</a>
<div class="hidden">

                                        <div data-popover-eventtype-course="1">
                                                <img class="icon " src="https://gracia.sallenet.org/theme/image.php/essential/quiz/1614308938/icon" alt="" title="">
                                            20-21) M07-UF1: Disseny i implementació d`interfícies-DAM2-M07-UF1: TAE Recursos Externs abre
                                        </div>
                                </div>
</td>
                    <td class="day text-center hasevent calendar_event_course duration_finish" data-eventtype-course="1" data-day-timestamp="1614898800">


<a href="https://gracia.sallenet.org/calendar/view.php?view=day&amp;time=1614898800" id="calendar-day-popover-link-1-2021-63-2" data-container="body" data-toggle="popover" data-html="true" data-trigger="hover" data-placement="top" data-title="viernes, 5 marzo eventos" data-alternate="No hay eventos" data-original-title="" title="">5</a>
<div class="hidden">

                                        <div data-popover-eventtype-course="1">
                                                <img class="icon " src="https://gracia.sallenet.org/theme/image.php/essential/assign/1614308938/icon" alt="" title="">
                                            20-21) M13-UF1: Projecte de desenvolupament d`aplicacions multiplataforma-DAM2-M13-UF1: Valoració Prototype 1 - 05/03 pendiente
                                        </div>
                                        <div data-popover-eventtype-course="1">
                                                <img class="icon " src="https://gracia.sallenet.org/theme/image.php/essential/assign/1614308938/icon" alt="" title="">
                                            20-21) M06-UF2: Persistència en BDR-BDOR-BDOO-DAM2-M06-UF2: Pràctica PR02 - Spotify pendiente
                                        </div>
                                </div>
</td>
                    <td class="day text-center weekend" data-day-timestamp="1614985200">                            6
                        </td>
                    <td class="day text-center weekend hasevent calendar_event_course duration_finish" data-eventtype-course="1" data-day-timestamp="1615071600">


<a href="https://gracia.sallenet.org/calendar/view.php?view=day&amp;time=1615071600" id="calendar-day-popover-link-1-2021-65-2" data-container="body" data-toggle="popover" data-html="true" data-trigger="hover" data-placement="top" data-title="domingo, 7 marzo eventos" data-alternate="No hay eventos" data-original-title="" title="">7</a>
<div class="hidden">

                                        <div data-popover-eventtype-course="1">
                                                <img class="icon " src="https://gracia.sallenet.org/theme/image.php/essential/assign/1614308938/icon" alt="" title="">
                                            20-21) M03-UF5: POO. Llibreries de classes fonamentals-DAM2-M03-UF5: M3-UF5-PR01 Segona Entrega pendiente
                                        </div>
                                </div>
</td>
            </tr>
            <tr data-region="month-view-week">
                    <td class="day text-center hasevent calendar_event_course duration_finish" data-eventtype-course="1" data-day-timestamp="1615158000">


<a href="https://gracia.sallenet.org/calendar/view.php?view=day&amp;time=1615158000" id="calendar-day-popover-link-1-2021-66-2" data-container="body" data-toggle="popover" data-html="true" data-trigger="hover" data-placement="top" data-title="lunes, 8 marzo eventos" data-alternate="No hay eventos" data-original-title="" title="">8</a>
<div class="hidden">

                                        <div data-popover-eventtype-course="1">
                                                <img class="icon " src="https://gracia.sallenet.org/theme/image.php/essential/assign/1614308938/icon" alt="" title="">
                                            20-21) M03-UF2: Disseny modular-DAM1-M03-UF2: POU04 - Amplia la classe Persona pendiente
                                        </div>
                                </div>
</td>
                    <td class="day text-center" data-day-timestamp="1615244400">                            9
                        </td>
                    <td class="day text-center" data-day-timestamp="1615330800">                            10
                        </td>
                    <td class="day text-center hasevent calendar_event_course duration_finish" data-eventtype-course="1" data-day-timestamp="1615417200">


<a href="https://gracia.sallenet.org/calendar/view.php?view=day&amp;time=1615417200" id="calendar-day-popover-link-1-2021-69-2" data-container="body" data-toggle="popover" data-html="true" data-trigger="hover" data-placement="top" data-title="jueves, 11 marzo eventos" data-alternate="No hay eventos" data-original-title="" title="">11</a>
<div class="hidden">

                                        <div data-popover-eventtype-course="1">
                                                <img class="icon " src="https://gracia.sallenet.org/theme/image.php/essential/assign/1614308938/icon" alt="" title="">
                                            20-21) M08-UF1: Desenvolupament d`aplicacions per dispositius mòbils-DAM2-M08-UF1: PRACTICA- Segunda entrega pendiente
                                        </div>
                                </div>
</td>
                    <td class="day text-center hasevent calendar_event_course duration_finish" data-eventtype-course="1" data-day-timestamp="1615503600">


<a href="https://gracia.sallenet.org/calendar/view.php?view=day&amp;time=1615503600" id="calendar-day-popover-link-1-2021-70-2" data-container="body" data-toggle="popover" data-html="true" data-trigger="hover" data-placement="top" data-title="viernes, 12 marzo eventos" data-alternate="No hay eventos" data-original-title="" title="">12</a>
<div class="hidden">

                                        <div data-popover-eventtype-course="1">
                                                <img class="icon " src="https://gracia.sallenet.org/theme/image.php/essential/assign/1614308938/icon" alt="" title="">
                                            20-21) M13-UF1: Projecte de desenvolupament d`aplicacions multiplataforma-DAM2-M13-UF1: Valoració Prototype 1 - 12/03 pendiente
                                        </div>
                                        <div data-popover-eventtype-course="1">
                                                <img class="icon " src="https://gracia.sallenet.org/theme/image.php/essential/assign/1614308938/icon" alt="" title="">
                                            20-21) M09-UF3: Sòcols i serveis-DAM2-M09-UF3: Pr1. Lliurament - Final pendiente
                                        </div>
                                        <div data-popover-eventtype-course="1">
                                                <img class="icon " src="https://gracia.sallenet.org/theme/image.php/essential/assign/1614308938/icon" alt="" title="">
                                            20-21) M13-UF1: Projecte de desenvolupament d`aplicacions multiplataforma-DAM2-M13-UF1: Item 06: Prototype 1 pendiente
                                        </div>
                                </div>
</td>
                    <td class="day text-center weekend" data-day-timestamp="1615590000">                            13
                        </td>
                    <td class="day text-center weekend hasevent calendar_event_course duration_finish" data-eventtype-course="1" data-day-timestamp="1615676400">


<a href="https://gracia.sallenet.org/calendar/view.php?view=day&amp;time=1615676400" id="calendar-day-popover-link-1-2021-72-2" data-container="body" data-toggle="popover" data-html="true" data-trigger="hover" data-placement="top" data-title="domingo, 14 marzo eventos" data-alternate="No hay eventos" data-original-title="" title="">14</a>
<div class="hidden">

                                        <div data-popover-eventtype-course="1">
                                                <img class="icon " src="https://gracia.sallenet.org/theme/image.php/essential/assign/1614308938/icon" alt="" title="">
                                            20-21) M03-UF2: Disseny modular-DAM1-M03-UF2: POU05 - ArrayList amb Classe pròpia pendiente
                                        </div>
                                </div>
</td>
            </tr>
            <tr data-region="month-view-week">
                    <td class="day text-center hasevent calendar_event_course duration_finish" data-eventtype-course="1" data-day-timestamp="1615762800">


<a href="https://gracia.sallenet.org/calendar/view.php?view=day&amp;time=1615762800" id="calendar-day-popover-link-1-2021-73-2" data-container="body" data-toggle="popover" data-html="true" data-trigger="hover" data-placement="top" data-title="lunes, 15 marzo eventos" data-alternate="No hay eventos" data-original-title="" title="">15</a>
<div class="hidden">

                                        <div data-popover-eventtype-course="1">
                                                <img class="icon " src="https://gracia.sallenet.org/theme/image.php/essential/assign/1614308938/icon" alt="" title="">
                                            20-21) M07-UF1: Disseny i implementació d`interfícies-DAM2-M07-UF1: Pràctica UF1 pendiente
                                        </div>
                                        <div data-popover-eventtype-course="1">
                                                <img class="icon " src="https://gracia.sallenet.org/theme/image.php/essential/choice/1614308938/icon" alt="" title="">
                                            20-21) M08-UF1: Desenvolupament d`aplicacions per dispositius mòbils-DAM2-M08-UF1: Entrevistas práctica M08-UF1 cierran
                                        </div>
                                </div>
</td>
                    <td class="day text-center hasevent calendar_event_course duration_finish" data-eventtype-course="1" data-day-timestamp="1615849200">


<a href="https://gracia.sallenet.org/calendar/view.php?view=day&amp;time=1615849200" id="calendar-day-popover-link-1-2021-74-2" data-container="body" data-toggle="popover" data-html="true" data-trigger="hover" data-placement="top" data-title="martes, 16 marzo eventos" data-alternate="No hay eventos" data-original-title="" title="">16</a>
<div class="hidden">

                                        <div data-popover-eventtype-course="1">
                                                <img class="icon " src="https://gracia.sallenet.org/theme/image.php/essential/quiz/1614308938/icon" alt="" title="">
                                            20-21) M05-UF3: Introducció al disseny orientat a objectes-DAM2-M05-UF3: TAE - Diagrames de casos d'ús, activitat y classes abre
                                        </div>
                                        <div data-popover-eventtype-course="1">
                                                <img class="icon " src="https://gracia.sallenet.org/theme/image.php/essential/quiz/1614308938/icon" alt="" title="">
                                            20-21) M05-UF3: Introducció al disseny orientat a objectes-DAM2-M05-UF3: Se cierra TAE - Diagrames de casos d'ús, activitat y classes
                                        </div>
                                </div>
</td>
                    <td class="day text-center hasevent calendar_event_course duration_finish" data-eventtype-course="1" data-day-timestamp="1615935600">


<a href="https://gracia.sallenet.org/calendar/view.php?view=day&amp;time=1615935600" id="calendar-day-popover-link-1-2021-75-2" data-container="body" data-toggle="popover" data-html="true" data-trigger="hover" data-placement="top" data-title="miércoles, 17 marzo eventos" data-alternate="No hay eventos" data-original-title="" title="">17</a>
<div class="hidden">

                                        <div data-popover-eventtype-course="1">
                                                <img class="icon " src="https://gracia.sallenet.org/theme/image.php/essential/assign/1614308938/icon" alt="" title="">
                                            20-21) M02-UF3: Llenguatge SQL: DCL i extensió procedimental-DAM1A-M02-UF3: POU 02: Cursors 3 pendiente
                                        </div>
                                </div>
</td>
                    <td class="day text-center" data-day-timestamp="1616022000">                            18
                        </td>
                    <td class="day text-center" data-day-timestamp="1616108400">                            19
                        </td>
                    <td class="day text-center weekend" data-day-timestamp="1616194800">                            20
                        </td>
                    <td class="day text-center weekend hasevent calendar_event_course duration_finish" data-eventtype-course="1" data-day-timestamp="1616281200">


<a href="https://gracia.sallenet.org/calendar/view.php?view=day&amp;time=1616281200" id="calendar-day-popover-link-1-2021-79-2" data-container="body" data-toggle="popover" data-html="true" data-trigger="hover" data-placement="top" data-title="domingo, 21 marzo eventos" data-alternate="No hay eventos" data-original-title="" title="">21</a>
<div class="hidden">

                                        <div data-popover-eventtype-course="1">
                                                <img class="icon " src="https://gracia.sallenet.org/theme/image.php/essential/assign/1614308938/icon" alt="" title="">
                                            20-21) M02-UF3: Llenguatge SQL: DCL i extensió procedimental-DAM1A-M02-UF3: POU 03: Gestió d'usuaris pendiente
                                        </div>
                                </div>
</td>
            </tr>
            <tr data-region="month-view-week">
                    <td class="day text-center" data-day-timestamp="1616367600">                            22
                        </td>
                    <td class="day text-center hasevent calendar_event_course duration_finish" data-eventtype-course="1" data-day-timestamp="1616454000">


<a href="https://gracia.sallenet.org/calendar/view.php?view=day&amp;time=1616454000" id="calendar-day-popover-link-1-2021-81-2" data-container="body" data-toggle="popover" data-html="true" data-trigger="hover" data-placement="top" data-title="martes, 23 marzo eventos" data-alternate="No hay eventos" data-original-title="" title="">23</a>
<div class="hidden">

                                        <div data-popover-eventtype-course="1">
                                                <img class="icon " src="https://gracia.sallenet.org/theme/image.php/essential/assign/1614308938/icon" alt="" title="">
                                            20-21) M09-UF1: Seguretat i criptografia-DAM2-M09-UF1: Ex1. Simulació atac - Codi pendiente
                                        </div>
                                </div>
</td>
                    <td class="day text-center hasevent calendar_event_course duration_finish" data-eventtype-course="1" data-day-timestamp="1616540400">


<a href="https://gracia.sallenet.org/calendar/view.php?view=day&amp;time=1616540400" id="calendar-day-popover-link-1-2021-82-2" data-container="body" data-toggle="popover" data-html="true" data-trigger="hover" data-placement="top" data-title="miércoles, 24 marzo eventos" data-alternate="No hay eventos" data-original-title="" title="">24</a>
<div class="hidden">

                                        <div data-popover-eventtype-course="1">
                                                <img class="icon " src="https://gracia.sallenet.org/theme/image.php/essential/quiz/1614308938/icon" alt="" title="">
                                            20-21) M03-UF6: POO. Introducció a la persistència en BD-DAM2-M03-UF6: TAE Accés a BBDD relacionals abre
                                        </div>
                                        <div data-popover-eventtype-course="1">
                                                <img class="icon " src="https://gracia.sallenet.org/theme/image.php/essential/quiz/1614308938/icon" alt="" title="">
                                            20-21) M03-UF6: POO. Introducció a la persistència en BD-DAM2-M03-UF6: Se cierra TAE Accés a BBDD relacionals
                                        </div>
                                        <div data-popover-eventtype-course="1">
                                                <img class="icon " src="https://gracia.sallenet.org/theme/image.php/essential/assign/1614308938/icon" alt="" title="">
                                            20-21) M03-UF6: POO. Introducció a la persistència en BD-DAM2-M03-UF6: POU CRUD Products pendiente
                                        </div>
                                </div>
</td>
                    <td class="day text-center hasevent calendar_event_course duration_finish" data-eventtype-course="1" data-day-timestamp="1616626800">


<a href="https://gracia.sallenet.org/calendar/view.php?view=day&amp;time=1616626800" id="calendar-day-popover-link-1-2021-83-2" data-container="body" data-toggle="popover" data-html="true" data-trigger="hover" data-placement="top" data-title="jueves, 25 marzo eventos" data-alternate="No hay eventos" data-original-title="" title="">25</a>
<div class="hidden">

                                        <div data-popover-eventtype-course="1">
                                                <img class="icon " src="https://gracia.sallenet.org/theme/image.php/essential/quiz/1614308938/icon" alt="" title="">
                                            20-21) M07-UF1: Disseny i implementació d`interfícies-DAM2-M07-UF1: Examen test UF1 abre
                                        </div>
                                        <div data-popover-eventtype-course="1">
                                                <img class="icon " src="https://gracia.sallenet.org/theme/image.php/essential/assign/1614308938/icon" alt="" title="">
                                            20-21) M03-UF2: Disseny modular-DAM1-M03-UF2: M03-UF2-PR01_Classes pendiente
                                        </div>
                                </div>
</td>
                    <td class="day text-center today hasevent calendar_event_course duration_finish" data-eventtype-course="1" data-day-timestamp="1616713200">


<a href="https://gracia.sallenet.org/calendar/view.php?view=day&amp;time=1616713200" id="calendar-day-popover-link-1-2021-84-2" data-container="body" data-toggle="popover" data-html="true" data-trigger="hover" data-placement="top" data-title="Hoy viernes, 26 marzo" data-alternate="No hay eventos" data-original-title="" title="">26</a>
<div class="hidden">

                                        <div data-popover-eventtype-course="1">
                                                <img class="icon " src="https://gracia.sallenet.org/theme/image.php/essential/quiz/1614308938/icon" alt="" title="">
                                            20-21) M07-UF1: Disseny i implementació d`interfícies-DAM2-M07-UF1: Se cierra Examen test UF1
                                        </div>
                                        <div data-popover-eventtype-course="1">
                                                <img class="icon " src="https://gracia.sallenet.org/theme/image.php/essential/assign/1614308938/icon" alt="" title="">
                                            20-21) M06-UF3: Persistència en BD natives XML-DAM2-M06-UF3: Entrega ICB0006-S06-C01-E pendiente
                                        </div>
                                        <div data-popover-eventtype-course="1">
                                                <img class="icon " src="https://gracia.sallenet.org/theme/image.php/essential/assign/1614308938/icon" alt="" title="">
                                            20-21) M02-UF3: Llenguatge SQL: DCL i extensió procedimental-DAM1A-M02-UF3: Venciment de M10-UF1 POU 04 (Triggers I)
                                        </div>
                                        <div data-popover-eventtype-course="1">
                                                <img class="icon " src="https://gracia.sallenet.org/theme/image.php/essential/assign/1614308938/icon" alt="" title="">
                                            20-21) M02-UF3: Llenguatge SQL: DCL i extensió procedimental-DAM1A-M02-UF3: Venciment de M10-UF1 POU 05 (Events I)
                                        </div>
                                </div>
</td>
                    <td class="day text-center weekend" data-day-timestamp="1616799600">                            27
                        </td>
                    <td class="day text-center weekend hasevent calendar_event_course duration_finish" data-eventtype-course="1" data-day-timestamp="1616886000">


<a href="https://gracia.sallenet.org/calendar/view.php?view=day&amp;time=1616886000" id="calendar-day-popover-link-1-2021-86-2" data-container="body" data-toggle="popover" data-html="true" data-trigger="hover" data-placement="top" data-title="domingo, 28 marzo eventos" data-alternate="No hay eventos" data-original-title="" title="">28</a>
<div class="hidden">

                                        <div data-popover-eventtype-course="1">
                                                <img class="icon " src="https://gracia.sallenet.org/theme/image.php/essential/assign/1614308938/icon" alt="" title="">
                                            20-21) M12-UF1: Empresa i iniciativa emprenedora-DAM1A-M12-UF1: Puntuació companys PR02 pendiente
                                        </div>
                                </div>
</td>
            </tr>
            <tr data-region="month-view-week">
                    <td class="day text-center" data-day-timestamp="1616968800">                            29
                        </td>
                    <td class="day text-center" data-day-timestamp="1617055200">                            30
                        </td>
                    <td class="day text-center" data-day-timestamp="1617141600">                            31
                        </td>
                    <td class="dayblank">&nbsp;</td>
                    <td class="dayblank">&nbsp;</td>
                    <td class="dayblank">&nbsp;</td>
                    <td class="dayblank">&nbsp;</td>
            </tr>
        </tbody>
    </table>
</div>
</div></div></div><span class="skip-block-to" id="sb-11"></span><a class="skip skip-block" id="fsb-12" href="#sb-12">Salta Mis cursos</a><div id="inst31852" class="block_course_list block list_block span4" role="navigation" data-block="course_list" data-instanceid="31852" aria-labelledby="instance-31852-header" data-dockable="1"><div class="header"><div class="title" id="yui_3_17_2_1_1616771229552_94"><div class="block_action"><i class="block-hider-hide icon fa fa-minus-square-o fa-fw" aria-hidden="true" aria-label="Oculta bloque Mis cursos" tabindex="0" title="Oculta bloque Mis cursos"></i><i class="block-hider-show icon fa fa-plus-square-o fa-fw" aria-hidden="true" aria-label="Muestra bloque Mis cursos" tabindex="0" title="Muestra bloque Mis cursos"></i><input type="image" class="moveto customcommand requiresjs" alt="Minimizar en la barra lateral" title="Acoplar bloque Mis cursos" src="https://gracia.sallenet.org/theme/image.php/essential/core/1614308938/t/block_to_dock"></div><span aria-hidden="true" class="fa fa-desktop"></span><h2 id="instance-31852-header">Mis cursos</h2></div></div><div class="content"><ul class="unlist"><li class="r0"><div class="column c1"><a title="20-21) M12: Empresa i iniciativa emprenedora-DAM1A-M12" href="https://gracia.sallenet.org/course/view.php?id=8231"><i class="icon fa fa-graduation-cap fa-fw " title="Curso" aria-label="Curso"></i>20-21) M12: Empresa i iniciativa emprenedora-DAM1A</a></div></li>
<li class="r1"><div class="column c1"><a title="20-21) M12-UF1: Empresa i iniciativa emprenedora-DAM1A-M12-UF1" href="https://gracia.sallenet.org/course/view.php?id=8230"><i class="icon fa fa-graduation-cap fa-fw " title="Curso" aria-label="Curso"></i>20-21) M12-UF1: Empresa i iniciativa emprenedora-DAM1A</a></div></li>
<li class="r0"><div class="column c1"><a title="20-21) M03-UF2: Disseny modular-DAM1-M03-UF2" href="https://gracia.sallenet.org/course/view.php?id=8216"><i class="icon fa fa-graduation-cap fa-fw " title="Curso" aria-label="Curso"></i>20-21) M03-UF2: Disseny modular-DAM1</a></div></li>
<li class="r1"><div class="column c1"><a title="20-21) M02: Bases de dades-DAM1A-M02" href="https://gracia.sallenet.org/course/view.php?id=8214"><i class="icon fa fa-graduation-cap fa-fw " title="Curso" aria-label="Curso"></i>20-21) M02: Bases de dades-DAM1A</a></div></li>
<li class="r0"><div class="column c1"><a title="20-21) M02-UF3: Llenguatge SQL: DCL i extensió procedimental-DAM1A-M02-UF3" href="https://gracia.sallenet.org/course/view.php?id=8212"><i class="icon fa fa-graduation-cap fa-fw " title="Curso" aria-label="Curso"></i>20-21) M02-UF3: Llenguatge SQL: DCL i extensió procedimental-DAM1A</a></div></li>
<li class="r1"><div class="column c1"><a title="20-21) M05: Entorns de desenvolupament-DAM2-M05" href="https://gracia.sallenet.org/course/view.php?id=8585"><i class="icon fa fa-graduation-cap fa-fw " title="Curso" aria-label="Curso"></i>20-21) M05: Entorns de desenvolupament-DAM2</a></div></li>
<li class="r0"><div class="column c1"><a title="20-21) M05-UF3: Introducció al disseny orientat a objectes-DAM2-M05-UF3" href="https://gracia.sallenet.org/course/view.php?id=8584"><i class="icon fa fa-graduation-cap fa-fw " title="Curso" aria-label="Curso"></i>20-21) M05-UF3: Introducció al disseny orientat a objectes-DAM2</a></div></li>
<li class="r1"><div class="column c1"><a title="20-21) M05-UF2: Optimització del programari-DAM2-M05-UF2" href="https://gracia.sallenet.org/course/view.php?id=8583"><i class="icon fa fa-graduation-cap fa-fw " title="Curso" aria-label="Curso"></i>20-21) M05-UF2: Optimització del programari-DAM2</a></div></li>
<li class="r0"><div class="column c1"><a title="20-21) M05-UF1: Desenvolupament de programari-DAM2-M05-UF1" href="https://gracia.sallenet.org/course/view.php?id=8582"><i class="icon fa fa-graduation-cap fa-fw " title="Curso" aria-label="Curso"></i>20-21) M05-UF1: Desenvolupament de programari-DAM2</a></div></li>
<li class="r1"><div class="column c1"><a title="20-21) M03: Programació-DAM2-M03" href="https://gracia.sallenet.org/course/view.php?id=8581"><i class="icon fa fa-graduation-cap fa-fw " title="Curso" aria-label="Curso"></i>20-21) M03: Programació-DAM2</a></div></li>
<li class="r0"><div class="column c1"><a title="20-21) M03-UF6: POO. Introducció a la persistència en BD-DAM2-M03-UF6" href="https://gracia.sallenet.org/course/view.php?id=8580"><i class="icon fa fa-graduation-cap fa-fw " title="Curso" aria-label="Curso"></i>20-21) M03-UF6: POO. Introducció a la persistència en BD-DAM2</a></div></li>
<li class="r1"><div class="column c1"><a title="20-21) M03-UF5: POO. Llibreries de classes fonamentals-DAM2-M03-UF5" href="https://gracia.sallenet.org/course/view.php?id=8579"><i class="icon fa fa-graduation-cap fa-fw " title="Curso" aria-label="Curso"></i>20-21) M03-UF5: POO. Llibreries de classes fonamentals-DAM2</a></div></li>
<li class="r0"><div class="column c1"><a title="20-21) M03-UF4: Programació orientada a objectes. Fonaments-DAM2-M03-UF4" href="https://gracia.sallenet.org/course/view.php?id=8578"><i class="icon fa fa-graduation-cap fa-fw " title="Curso" aria-label="Curso"></i>20-21) M03-UF4: Programació orientada a objectes. Fonaments-DAM2</a></div></li>
<li class="r1"><div class="column c1"><a title="20-21) M14: Formació en centres de treball-DAM2-M14" href="https://gracia.sallenet.org/course/view.php?id=8278"><i class="icon fa fa-graduation-cap fa-fw " title="Curso" aria-label="Curso"></i>20-21) M14: Formació en centres de treball-DAM2</a></div></li>
<li class="r0"><div class="column c1"><a title="20-21) M14-UF1: Formació en centres de treball-DAM2-M14-UF1" href="https://gracia.sallenet.org/course/view.php?id=8277"><i class="icon fa fa-graduation-cap fa-fw " title="Curso" aria-label="Curso"></i>20-21) M14-UF1: Formació en centres de treball-DAM2</a></div></li>
<li class="r1"><div class="column c1"><a title="20-21) M13: Projecte de  desenvolupament  d’aplicacions multiplataforma-DAM2-M13" href="https://gracia.sallenet.org/course/view.php?id=8276"><i class="icon fa fa-graduation-cap fa-fw " title="Curso" aria-label="Curso"></i>20-21) M13: Projecte de  desenvolupament  d’aplicacions multiplataforma-DAM2</a></div></li>
<li class="r0"><div class="column c1"><a title="20-21) M13-UF1: Projecte de desenvolupament d`aplicacions multiplataforma-DAM2-M13-UF1" href="https://gracia.sallenet.org/course/view.php?id=8275"><i class="icon fa fa-graduation-cap fa-fw " title="Curso" aria-label="Curso"></i>20-21) M13-UF1: Projecte de desenvolupament d`aplicacions multiplataforma-DAM2</a></div></li>
<li class="r1"><div class="column c1"><a title="20-21) M10: Sistemes de gestió  empresarial-DAM2-M10" href="https://gracia.sallenet.org/course/view.php?id=8274"><i class="icon fa fa-graduation-cap fa-fw " title="Curso" aria-label="Curso"></i>20-21) M10: Sistemes de gestió  empresarial-DAM2</a></div></li>
<li class="r0"><div class="column c1"><a title="20-21) M10-UF2: Sistemes ERP-CRM. Explotació i adequació.-DAM2-M10-UF2" href="https://gracia.sallenet.org/course/view.php?id=8273"><i class="icon fa fa-graduation-cap fa-fw " title="Curso" aria-label="Curso"></i>20-21) M10-UF2: Sistemes ERP-CRM. Explotació i adequació.-DAM2</a></div></li>
<li class="r1"><div class="column c1"><a title="20-21) M10-UF1: Sistemes ERP-CRM. Implantació.-DAM2-M10-UF1" href="https://gracia.sallenet.org/course/view.php?id=8272"><i class="icon fa fa-graduation-cap fa-fw " title="Curso" aria-label="Curso"></i>20-21) M10-UF1: Sistemes ERP-CRM. Implantació.-DAM2</a></div></li>
<li class="r0"><div class="column c1"><a title="20-21) M09: Programació de serveis  i processos-DAM2-M09" href="https://gracia.sallenet.org/course/view.php?id=8271"><i class="icon fa fa-graduation-cap fa-fw " title="Curso" aria-label="Curso"></i>20-21) M09: Programació de serveis  i processos-DAM2</a></div></li>
<li class="r1"><div class="column c1"><a title="20-21) M09-UF3: Sòcols i serveis-DAM2-M09-UF3" href="https://gracia.sallenet.org/course/view.php?id=8270"><i class="icon fa fa-graduation-cap fa-fw " title="Curso" aria-label="Curso"></i>20-21) M09-UF3: Sòcols i serveis-DAM2</a></div></li>
<li class="r0"><div class="column c1"><a title="20-21) M09-UF2: Processos i fils-DAM2-M09-UF2" href="https://gracia.sallenet.org/course/view.php?id=8269"><i class="icon fa fa-graduation-cap fa-fw " title="Curso" aria-label="Curso"></i>20-21) M09-UF2: Processos i fils-DAM2</a></div></li>
<li class="r1"><div class="column c1"><a title="20-21) M09-UF1: Seguretat i criptografia-DAM2-M09-UF1" href="https://gracia.sallenet.org/course/view.php?id=8268"><i class="icon fa fa-graduation-cap fa-fw " title="Curso" aria-label="Curso"></i>20-21) M09-UF1: Seguretat i criptografia-DAM2</a></div></li>
<li class="r0"><div class="column c1"><a title="20-21) M08: Programació multimèdia  i dispositius mòbils-DAM2-M08" href="https://gracia.sallenet.org/course/view.php?id=8267"><i class="icon fa fa-graduation-cap fa-fw " title="Curso" aria-label="Curso"></i>20-21) M08: Programació multimèdia  i dispositius mòbils-DAM2</a></div></li>
<li class="r1"><div class="column c1"><a title="20-21) M08-UF3: Desenvolupament de jocs per dispositius mòbils-DAM2-M08-UF3" href="https://gracia.sallenet.org/course/view.php?id=8266"><i class="icon fa fa-graduation-cap fa-fw " title="Curso" aria-label="Curso"></i>20-21) M08-UF3: Desenvolupament de jocs per dispositius mòbils-DAM2</a></div></li>
<li class="r0"><div class="column c1"><a title="20-21) M08-UF2: Programació multimèdia-DAM2-M08-UF2" href="https://gracia.sallenet.org/course/view.php?id=8265"><i class="icon fa fa-graduation-cap fa-fw " title="Curso" aria-label="Curso"></i>20-21) M08-UF2: Programació multimèdia-DAM2</a></div></li>
<li class="r1"><div class="column c1"><a title="20-21) M08-UF1: Desenvolupament d`aplicacions per dispositius mòbils-DAM2-M08-UF1" href="https://gracia.sallenet.org/course/view.php?id=8264"><i class="icon fa fa-graduation-cap fa-fw " title="Curso" aria-label="Curso"></i>20-21) M08-UF1: Desenvolupament d`aplicacions per dispositius mòbils-DAM2</a></div></li>
<li class="r0"><div class="column c1"><a title="20-21) M07: Desenvolupament  d’interfícies-DAM2-M07" href="https://gracia.sallenet.org/course/view.php?id=8263"><i class="icon fa fa-graduation-cap fa-fw " title="Curso" aria-label="Curso"></i>20-21) M07: Desenvolupament  d’interfícies-DAM2</a></div></li>
<li class="r1"><div class="column c1"><a title="20-21) M07-UF2: Preparació i distribució d`aplicacions-DAM2-M07-UF2" href="https://gracia.sallenet.org/course/view.php?id=8262"><i class="icon fa fa-graduation-cap fa-fw " title="Curso" aria-label="Curso"></i>20-21) M07-UF2: Preparació i distribució d`aplicacions-DAM2</a></div></li>
<li class="r0"><div class="column c1"><a title="20-21) M07-UF1: Disseny i implementació d`interfícies-DAM2-M07-UF1" href="https://gracia.sallenet.org/course/view.php?id=8261"><i class="icon fa fa-graduation-cap fa-fw " title="Curso" aria-label="Curso"></i>20-21) M07-UF1: Disseny i implementació d`interfícies-DAM2</a></div></li>
<li class="r1"><div class="column c1"><a title="20-21) M06: Accés a dades-DAM2-M06" href="https://gracia.sallenet.org/course/view.php?id=8260"><i class="icon fa fa-graduation-cap fa-fw " title="Curso" aria-label="Curso"></i>20-21) M06: Accés a dades-DAM2</a></div></li>
<li class="r0"><div class="column c1"><a title="20-21) M06-UF4: Components d'accés a dades-DAM2-M06-UF4" href="https://gracia.sallenet.org/course/view.php?id=8259"><i class="icon fa fa-graduation-cap fa-fw " title="Curso" aria-label="Curso"></i>20-21) M06-UF4: Components d'accés a dades-DAM2</a></div></li>
<li class="r1"><div class="column c1"><a title="20-21) M06-UF3: Persistència en BD natives XML-DAM2-M06-UF3" href="https://gracia.sallenet.org/course/view.php?id=8258"><i class="icon fa fa-graduation-cap fa-fw " title="Curso" aria-label="Curso"></i>20-21) M06-UF3: Persistència en BD natives XML-DAM2</a></div></li>
<li class="r0"><div class="column c1"><a title="20-21) M06-UF2: Persistència en BDR-BDOR-BDOO-DAM2-M06-UF2" href="https://gracia.sallenet.org/course/view.php?id=8257"><i class="icon fa fa-graduation-cap fa-fw " title="Curso" aria-label="Curso"></i>20-21) M06-UF2: Persistència en BDR-BDOR-BDOO-DAM2</a></div></li>
<li class="r1"><div class="column c1"><a title="20-21) M06-UF1: Persistència en fitxers-DAM2-M06-UF1" href="https://gracia.sallenet.org/course/view.php?id=8256"><i class="icon fa fa-graduation-cap fa-fw " title="Curso" aria-label="Curso"></i>20-21) M06-UF1: Persistència en fitxers-DAM2</a></div></li>
<li class="r0"><div class="column c1"><a title="TUT 2020-2021 CFS2B - DAM2 - A" href="https://gracia.sallenet.org/course/view.php?id=8255"><i class="icon fa fa-graduation-cap fa-fw " title="Curso" aria-label="Curso"></i>20-21) Tutoría - CFS2B - DAM2 - A</a></div></li></ul><div class="footer"><a href="https://gracia.sallenet.org/course/index.php">Todos los cursos</a> ...</div></div></div><span class="skip-block-to" id="sb-12"></span></div></aside><section id="region-main"><span class="notifications" id="user-notifications"></span><div role="main"><span id="maincontent"></span><a class="skip skip-block" href="#skipmycourses">Salta mis cursos</a><div id="frontpage-course-list"><h2>Mis cursos</h2><div class="courses frontpage-course-list-enrolled"><div class="coursebox clearfix odd first" data-courseid="8231" data-type="1"><div class="info"><h3 class="coursename"><a class="" href="https://gracia.sallenet.org/course/view.php?id=8231">20-21) M12: Empresa i iniciativa emprenedora-DAM1A</a></h3><div class="moreinfo"></div></div><div class="content"></div></div><div class="coursebox clearfix even" data-courseid="8230" data-type="1"><div class="info"><h3 class="coursename"><a class="" href="https://gracia.sallenet.org/course/view.php?id=8230">20-21) M12-UF1: Empresa i iniciativa emprenedora-DAM1A</a></h3><div class="moreinfo"></div></div><div class="content"></div></div><div class="coursebox clearfix odd" data-courseid="8216" data-type="1"><div class="info"><h3 class="coursename"><a class="" href="https://gracia.sallenet.org/course/view.php?id=8216">20-21) M03-UF2: Disseny modular-DAM1</a></h3><div class="moreinfo"></div></div><div class="content"></div></div><div class="coursebox clearfix even" data-courseid="8214" data-type="1"><div class="info"><h3 class="coursename"><a class="" href="https://gracia.sallenet.org/course/view.php?id=8214">20-21) M02: Bases de dades-DAM1A</a></h3><div class="moreinfo"></div></div><div class="content"></div></div><div class="coursebox clearfix odd" data-courseid="8212" data-type="1"><div class="info"><h3 class="coursename"><a class="" href="https://gracia.sallenet.org/course/view.php?id=8212">20-21) M02-UF3: Llenguatge SQL: DCL i extensió procedimental-DAM1A</a></h3><div class="moreinfo"></div></div><div class="content"></div></div><div class="coursebox clearfix even" data-courseid="8585" data-type="1"><div class="info"><h3 class="coursename"><a class="" href="https://gracia.sallenet.org/course/view.php?id=8585">20-21) M05: Entorns de desenvolupament-DAM2</a></h3><div class="moreinfo"></div></div><div class="content"></div></div><div class="coursebox clearfix odd" data-courseid="8584" data-type="1"><div class="info"><h3 class="coursename"><a class="" href="https://gracia.sallenet.org/course/view.php?id=8584">20-21) M05-UF3: Introducció al disseny orientat a objectes-DAM2</a></h3><div class="moreinfo"></div></div><div class="content"></div></div><div class="coursebox clearfix even" data-courseid="8583" data-type="1"><div class="info"><h3 class="coursename"><a class="" href="https://gracia.sallenet.org/course/view.php?id=8583">20-21) M05-UF2: Optimització del programari-DAM2</a></h3><div class="moreinfo"></div></div><div class="content"></div></div><div class="coursebox clearfix odd" data-courseid="8582" data-type="1"><div class="info"><h3 class="coursename"><a class="" href="https://gracia.sallenet.org/course/view.php?id=8582">20-21) M05-UF1: Desenvolupament de programari-DAM2</a></h3><div class="moreinfo"></div></div><div class="content"></div></div><div class="coursebox clearfix even" data-courseid="8581" data-type="1"><div class="info"><h3 class="coursename"><a class="" href="https://gracia.sallenet.org/course/view.php?id=8581">20-21) M03: Programació-DAM2</a></h3><div class="moreinfo"></div></div><div class="content"></div></div><div class="coursebox clearfix odd" data-courseid="8580" data-type="1"><div class="info"><h3 class="coursename"><a class="" href="https://gracia.sallenet.org/course/view.php?id=8580">20-21) M03-UF6: POO. Introducció a la persistència en BD-DAM2</a></h3><div class="moreinfo"></div></div><div class="content"></div></div><div class="coursebox clearfix even" data-courseid="8579" data-type="1"><div class="info"><h3 class="coursename"><a class="" href="https://gracia.sallenet.org/course/view.php?id=8579">20-21) M03-UF5: POO. Llibreries de classes fonamentals-DAM2</a></h3><div class="moreinfo"></div></div><div class="content"></div></div><div class="coursebox clearfix odd" data-courseid="8578" data-type="1"><div class="info"><h3 class="coursename"><a class="" href="https://gracia.sallenet.org/course/view.php?id=8578">20-21) M03-UF4: Programació orientada a objectes. Fonaments-DAM2</a></h3><div class="moreinfo"></div></div><div class="content"></div></div><div class="coursebox clearfix even" data-courseid="8278" data-type="1"><div class="info"><h3 class="coursename"><a class="" href="https://gracia.sallenet.org/course/view.php?id=8278">20-21) M14: Formació en centres de treball-DAM2</a></h3><div class="moreinfo"></div></div><div class="content"></div></div><div class="coursebox clearfix odd" data-courseid="8277" data-type="1"><div class="info"><h3 class="coursename"><a class="" href="https://gracia.sallenet.org/course/view.php?id=8277">20-21) M14-UF1: Formació en centres de treball-DAM2</a></h3><div class="moreinfo"></div></div><div class="content"></div></div><div class="coursebox clearfix even" data-courseid="8276" data-type="1"><div class="info"><h3 class="coursename"><a class="" href="https://gracia.sallenet.org/course/view.php?id=8276">20-21) M13: Projecte de  desenvolupament  d’aplicacions multiplataforma-DAM2</a></h3><div class="moreinfo"></div></div><div class="content"></div></div><div class="coursebox clearfix odd" data-courseid="8275" data-type="1"><div class="info"><h3 class="coursename"><a class="" href="https://gracia.sallenet.org/course/view.php?id=8275">20-21) M13-UF1: Projecte de desenvolupament d`aplicacions multiplataforma-DAM2</a></h3><div class="moreinfo"></div></div><div class="content"></div></div><div class="coursebox clearfix even" data-courseid="8274" data-type="1"><div class="info"><h3 class="coursename"><a class="" href="https://gracia.sallenet.org/course/view.php?id=8274">20-21) M10: Sistemes de gestió  empresarial-DAM2</a></h3><div class="moreinfo"></div></div><div class="content"></div></div><div class="coursebox clearfix odd" data-courseid="8273" data-type="1"><div class="info"><h3 class="coursename"><a class="" href="https://gracia.sallenet.org/course/view.php?id=8273">20-21) M10-UF2: Sistemes ERP-CRM. Explotació i adequació.-DAM2</a></h3><div class="moreinfo"></div></div><div class="content"></div></div><div class="coursebox clearfix even" data-courseid="8272" data-type="1"><div class="info"><h3 class="coursename"><a class="" href="https://gracia.sallenet.org/course/view.php?id=8272">20-21) M10-UF1: Sistemes ERP-CRM. Implantació.-DAM2</a></h3><div class="moreinfo"></div></div><div class="content"></div></div><div class="coursebox clearfix odd" data-courseid="8271" data-type="1"><div class="info"><h3 class="coursename"><a class="" href="https://gracia.sallenet.org/course/view.php?id=8271">20-21) M09: Programació de serveis  i processos-DAM2</a></h3><div class="moreinfo"></div></div><div class="content"></div></div><div class="coursebox clearfix even" data-courseid="8270" data-type="1"><div class="info"><h3 class="coursename"><a class="" href="https://gracia.sallenet.org/course/view.php?id=8270">20-21) M09-UF3: Sòcols i serveis-DAM2</a></h3><div class="moreinfo"></div></div><div class="content"></div></div><div class="coursebox clearfix odd" data-courseid="8269" data-type="1"><div class="info"><h3 class="coursename"><a class="" href="https://gracia.sallenet.org/course/view.php?id=8269">20-21) M09-UF2: Processos i fils-DAM2</a></h3><div class="moreinfo"></div></div><div class="content"></div></div><div class="coursebox clearfix even" data-courseid="8268" data-type="1"><div class="info"><h3 class="coursename"><a class="" href="https://gracia.sallenet.org/course/view.php?id=8268">20-21) M09-UF1: Seguretat i criptografia-DAM2</a></h3><div class="moreinfo"></div></div><div class="content"></div></div><div class="coursebox clearfix odd" data-courseid="8267" data-type="1"><div class="info"><h3 class="coursename"><a class="" href="https://gracia.sallenet.org/course/view.php?id=8267">20-21) M08: Programació multimèdia  i dispositius mòbils-DAM2</a></h3><div class="moreinfo"></div></div><div class="content"></div></div><div class="coursebox clearfix even" data-courseid="8266" data-type="1"><div class="info"><h3 class="coursename"><a class="" href="https://gracia.sallenet.org/course/view.php?id=8266">20-21) M08-UF3: Desenvolupament de jocs per dispositius mòbils-DAM2</a></h3><div class="moreinfo"></div></div><div class="content"></div></div><div class="coursebox clearfix odd" data-courseid="8265" data-type="1"><div class="info"><h3 class="coursename"><a class="" href="https://gracia.sallenet.org/course/view.php?id=8265">20-21) M08-UF2: Programació multimèdia-DAM2</a></h3><div class="moreinfo"></div></div><div class="content"></div></div><div class="coursebox clearfix even" data-courseid="8264" data-type="1"><div class="info"><h3 class="coursename"><a class="" href="https://gracia.sallenet.org/course/view.php?id=8264">20-21) M08-UF1: Desenvolupament d`aplicacions per dispositius mòbils-DAM2</a></h3><div class="moreinfo"></div></div><div class="content"></div></div><div class="coursebox clearfix odd" data-courseid="8263" data-type="1"><div class="info"><h3 class="coursename"><a class="" href="https://gracia.sallenet.org/course/view.php?id=8263">20-21) M07: Desenvolupament  d’interfícies-DAM2</a></h3><div class="moreinfo"></div></div><div class="content"></div></div><div class="coursebox clearfix even" data-courseid="8262" data-type="1"><div class="info"><h3 class="coursename"><a class="" href="https://gracia.sallenet.org/course/view.php?id=8262">20-21) M07-UF2: Preparació i distribució d`aplicacions-DAM2</a></h3><div class="moreinfo"></div></div><div class="content"></div></div><div class="coursebox clearfix odd" data-courseid="8261" data-type="1"><div class="info"><h3 class="coursename"><a class="" href="https://gracia.sallenet.org/course/view.php?id=8261">20-21) M07-UF1: Disseny i implementació d`interfícies-DAM2</a></h3><div class="moreinfo"></div></div><div class="content"></div></div><div class="coursebox clearfix even" data-courseid="8260" data-type="1"><div class="info"><h3 class="coursename"><a class="" href="https://gracia.sallenet.org/course/view.php?id=8260">20-21) M06: Accés a dades-DAM2</a></h3><div class="moreinfo"></div></div><div class="content"></div></div><div class="coursebox clearfix odd" data-courseid="8259" data-type="1"><div class="info"><h3 class="coursename"><a class="" href="https://gracia.sallenet.org/course/view.php?id=8259">20-21) M06-UF4: Components d'accés a dades-DAM2</a></h3><div class="moreinfo"></div></div><div class="content"></div></div><div class="coursebox clearfix even" data-courseid="8258" data-type="1"><div class="info"><h3 class="coursename"><a class="" href="https://gracia.sallenet.org/course/view.php?id=8258">20-21) M06-UF3: Persistència en BD natives XML-DAM2</a></h3><div class="moreinfo"></div></div><div class="content"></div></div><div class="coursebox clearfix odd" data-courseid="8257" data-type="1"><div class="info"><h3 class="coursename"><a class="" href="https://gracia.sallenet.org/course/view.php?id=8257">20-21) M06-UF2: Persistència en BDR-BDOR-BDOO-DAM2</a></h3><div class="moreinfo"></div></div><div class="content"></div></div><div class="coursebox clearfix even" data-courseid="8256" data-type="1"><div class="info"><h3 class="coursename"><a class="" href="https://gracia.sallenet.org/course/view.php?id=8256">20-21) M06-UF1: Persistència en fitxers-DAM2</a></h3><div class="moreinfo"></div></div><div class="content"></div></div><div class="coursebox clearfix odd last" data-courseid="8255" data-type="1"><div class="info"><h3 class="coursename"><a class="" href="https://gracia.sallenet.org/course/view.php?id=8255">20-21) Tutoría - CFS2B - DAM2 - A</a></h3><div class="moreinfo"></div></div><div class="content"></div></div><div class="paging paging-morelink"><a href="https://gracia.sallenet.org/course/index.php">Todos los cursos</a></div></div></div><span class="skip-block-to" id="skipmycourses"></span><br></div></section></div><aside id="block-region-side-pre" class="span3 desktop-first-column block-region" data-blockregion="side-pre" data-droptarget="1"><a class="skip skip-block" id="fsb-1" href="#sb-1">Salta MENU MARÇ 2021</a><div id="inst35865" class="block_html block" role="complementary" data-block="html" data-instanceid="35865" aria-labelledby="instance-35865-header" data-dockable="1"><div class="header"><div class="title" id="yui_3_17_2_1_1616771229552_110"><div class="block_action"><i class="block-hider-hide icon fa fa-minus-square-o fa-fw" aria-hidden="true" aria-label="Oculta bloque MENU MARÇ 2021" tabindex="0" title="Oculta bloque MENU MARÇ 2021"></i><i class="block-hider-show icon fa fa-plus-square-o fa-fw" aria-hidden="true" aria-label="Muestra bloque MENU MARÇ 2021" tabindex="0" title="Muestra bloque MENU MARÇ 2021"></i><input type="image" class="moveto customcommand requiresjs" alt="Minimizar en la barra lateral" title="Acoplar bloque MENU MARÇ 2021" src="https://gracia.sallenet.org/theme/image.php/essential/core/1614308938/t/block_to_dock"></div><span aria-hidden="true" class="fa fa-list-alt"></span><h2 id="instance-35865-header">MENU MARÇ 2021</h2></div></div><div class="content"><div class="no-overflow"><p style="text-align: center;"><a href="https://gracia.sallenet.org/pluginfile.php/208574/block_html/content/menus.pdf"><img src="https://gracia.sallenet.org/pluginfile.php/208574/block_html/content/dan-gold-4_jhDO54BYg-unsplash.jpg" alt="" width="300" height="200" role="presentation" class="img-responsive atto_image_button_text-bottom"></a></p></div></div></div><span class="skip-block-to" id="sb-1"></span><div id="inst37125" class="block_html block" role="complementary" data-block="html" data-instanceid="37125" aria-label="HTML"><div class="content"><div class="block_action notitle"></div><div class="no-overflow"><p style="text-align: center;"><a href="https://gracia.sallenet.org/pluginfile.php/217665/block_html/content/Informacio%CC%81n_COVID_en_Sallenet_y_Web.zip"><img src="https://gracia.sallenet.org/pluginfile.php/217665/block_html/content/Infografia_Mesures_prevencio.jpg" width="350" height="875"></a></p></div></div></div><a class="skip skip-block" id="fsb-6" href="#sb-6">Salta Eventos próximos</a><div id="inst31891" class="block_calendar_upcoming block" role="complementary" data-block="calendar_upcoming" data-instanceid="31891" aria-labelledby="instance-31891-header" data-dockable="1"><div class="header"><div class="title" id="yui_3_17_2_1_1616771229552_126"><div class="block_action"><i class="block-hider-hide icon fa fa-minus-square-o fa-fw" aria-hidden="true" aria-label="Oculta bloque Eventos próximos" tabindex="0" title="Oculta bloque Eventos próximos"></i><i class="block-hider-show icon fa fa-plus-square-o fa-fw" aria-hidden="true" aria-label="Muestra bloque Eventos próximos" tabindex="0" title="Muestra bloque Eventos próximos"></i><input type="image" class="moveto customcommand requiresjs" alt="Minimizar en la barra lateral" title="Acoplar bloque Eventos próximos" src="https://gracia.sallenet.org/theme/image.php/essential/core/1614308938/t/block_to_dock"></div><span aria-hidden="true" class="fa fa-calendar"></span><h2 id="instance-31891-header">Eventos próximos</h2></div></div><div class="content"><div id="calendar-upcoming-block-605df8a09058c605df8a0905e21" data-template="core_calendar/upcoming_mini">
    <div class="card-text content calendarwrapper" id="month-upcoming-mini-605df8a09058c605df8a0905e21" data-context-id="2" data-courseid="1" data-categoryid="0">
        <span class="overlay-icon-container hidden" data-region="overlay-icon-container">
            <span class="loading-icon"><i class="icon fa fa-circle-o-notch fa-spin fa-fw " title="Enviando" aria-label="Enviando"></i></span>
        </span>
            <div class="event" data-eventtype-course="1" data-region="event-item">
                <span><img class="icon " alt="Evento de actividad" title="Evento de actividad" src="https://gracia.sallenet.org/theme/image.php/essential/assign/1614308938/icon"></span>
                <a data-type="event" data-action="view-event" data-event-id="65084" href="https://gracia.sallenet.org/calendar/view.php?view=day&amp;course=8258&amp;time=1616799300#event_65084">Entrega ICB0006-S06-C01-E pendiente</a>
                <div class="date"><a href="https://gracia.sallenet.org/calendar/view.php?view=day&amp;time=1616799300">Hoy</a>, 23:55</div>
                <hr>
            </div>
            <div class="event" data-eventtype-course="1" data-region="event-item">
                <span><img class="icon " alt="Evento de actividad" title="Evento de actividad" src="https://gracia.sallenet.org/theme/image.php/essential/assign/1614308938/icon"></span>
                <a data-type="event" data-action="view-event" data-event-id="63848" href="https://gracia.sallenet.org/calendar/view.php?view=day&amp;course=8212&amp;time=1616799540#event_63848">Venciment de M10-UF1 POU 04 (Triggers I)</a>
                <div class="date"><a href="https://gracia.sallenet.org/calendar/view.php?view=day&amp;time=1616799540">Hoy</a>, 23:59</div>
                <hr>
            </div>
    </div>
</div><div class="footer"><div class="gotocal"><a href="https://gracia.sallenet.org/calendar/view.php?view=upcoming">Ir al calendario...</a></div></div></div></div><span class="skip-block-to" id="sb-6"></span><a class="skip skip-block" id="fsb-7" href="#sb-7">Salta ALAMBIQUE</a><div id="inst38350" class="block_html block" role="complementary" data-block="html" data-instanceid="38350" aria-labelledby="instance-38350-header" data-dockable="1"><div class="header"><div class="title" id="yui_3_17_2_1_1616771229552_142"><div class="block_action"><i class="block-hider-hide icon fa fa-minus-square-o fa-fw" aria-hidden="true" aria-label="Oculta bloque ALAMBIQUE" tabindex="0" title="Oculta bloque ALAMBIQUE"></i><i class="block-hider-show icon fa fa-plus-square-o fa-fw" aria-hidden="true" aria-label="Muestra bloque ALAMBIQUE" tabindex="0" title="Muestra bloque ALAMBIQUE"></i><input type="image" class="moveto customcommand requiresjs" alt="Minimizar en la barra lateral" title="Acoplar bloque ALAMBIQUE" src="https://gracia.sallenet.org/theme/image.php/essential/core/1614308938/t/block_to_dock"></div><span aria-hidden="true" class="fa fa-list-alt"></span><h2 id="instance-38350-header">ALAMBIQUE</h2></div></div><div class="content"><div class="no-overflow"><p><a href="https://gracia.sallenet.org/auth/mnet/jump.php?hostid=7"><img src="https://gracia.sallenet.org/pluginfile.php/223515/block_html/content/alambique_banner.png" alt="Alambique" width="356" height="156" class="img-responsive atto_image_button_text-bottom"></a><br></p></div></div></div><span class="skip-block-to" id="sb-7"></span></aside>            </section>
        </div>

        <!-- End Main Regions -->

        
    </section>
</div>

    <footer role="contentinfo" id="page-footer" style="position: relative; top: 0.666406px; left: 0px;">
        <div class="container-fluid">
                        <div class="row-fluid footerblocks">
                <div class="footerblock span4">
                                    </div>
                <div class="footerblock span4">
                                    </div>
                <div class="footerblock span4">
                                    </div>
            </div>
            <div class="row-fluid">
                <div class="tool_usertours-resettourcontainer span12" id="yui_3_17_2_1_1616771229552_160"><div class="usertour">
    <a href="#" data-action="tool_usertours/resetpagetour">Reiniciar tour para usuario en esta página</a>
</div></div>
            </div>
            <div class="footerlinks row-fluid">
                <hr>
                <span class="helplink"></span>
                                    <span class="copy">©2021 Copyright © La Salle Gracia</span>
                                            </div>
            <div class="footerperformance row-fluid">
                <div class="tool_dataprivacy"><a href="https://gracia.sallenet.org/admin/tool/dataprivacy/summary.php">Resumen de conservación de datos</a></div><a href="https://download.moodle.org/mobile?version=2018051706&amp;lang=es&amp;iosappid=633359593&amp;androidappid=com.moodle.moodlemobile">Descargar la app para dispositivos móviles</a>            </div>
        </div>
    </footer>
    <a href="#top" class="back-to-top" aria-label="Volver arriba" style="display: none;">
        <span aria-hidden="true" class="fa fa-angle-up "></span></a>
<script type="text/javascript">
//<![CDATA[
var require = {
    baseUrl : 'https://gracia.sallenet.org/lib/requirejs.php/1614308938/',
    // We only support AMD modules with an explicit define() statement.
    enforceDefine: true,
    skipDataMain: true,
    waitSeconds : 0,

    paths: {
        jquery: 'https://gracia.sallenet.org/lib/javascript.php/1614308938/lib/jquery/jquery-3.2.1.min',
        jqueryui: 'https://gracia.sallenet.org/lib/javascript.php/1614308938/lib/jquery/ui-1.12.1/jquery-ui.min',
        jqueryprivate: 'https://gracia.sallenet.org/lib/javascript.php/1614308938/lib/requirejs/jquery-private'
    },

    // Custom jquery config map.
    map: {
      // '*' means all modules will get 'jqueryprivate'
      // for their 'jquery' dependency.
      '*': { jquery: 'jqueryprivate' },
      // Stub module for 'process'. This is a workaround for a bug in MathJax (see MDL-60458).
      '*': { process: 'core/first' },

      // 'jquery-private' wants the real jQuery module
      // though. If this line was not here, there would
      // be an unresolvable cyclic dependency.
      jqueryprivate: { jquery: 'jquery' }
    }
};

//]]>
</script>
<script type="text/javascript" src="https://gracia.sallenet.org/lib/javascript.php/1614308938/lib/requirejs/require.min.js"></script>
<script type="text/javascript">
//<![CDATA[
require(['core/first'], function() {
;
require(["media_videojs/loader"], function(loader) {
    loader.setUp(function(videojs) {
        videojs.options.flash.swf = "https://gracia.sallenet.org/media/player/videojs/videojs/video-js.swf";
videojs.addLanguage("es",{
 "Play": "Reproducción",
 "Play Video": "Reproducción Vídeo",
 "Pause": "Pausa",
 "Current Time": "Tiempo reproducido",
 "Duration Time": "Duración total",
 "Remaining Time": "Tiempo restante",
 "Stream Type": "Tipo de secuencia",
 "LIVE": "DIRECTO",
 "Loaded": "Cargado",
 "Progress": "Progreso",
 "Fullscreen": "Pantalla completa",
 "Non-Fullscreen": "Pantalla no completa",
 "Mute": "Silenciar",
 "Unmute": "No silenciado",
 "Playback Rate": "Velocidad de reproducción",
 "Subtitles": "Subtítulos",
 "subtitles off": "Subtítulos desactivados",
 "Captions": "Subtítulos especiales",
 "captions off": "Subtítulos especiales desactivados",
 "Chapters": "Capítulos",
 "You aborted the media playback": "Ha interrumpido la reproducción del vídeo.",
 "A network error caused the media download to fail part-way.": "Un error de red ha interrumpido la descarga del vídeo.",
 "The media could not be loaded, either because the server or network failed or because the format is not supported.": "No se ha podido cargar el vídeo debido a un fallo de red o del servidor o porque el formato es incompatible.",
 "The media playback was aborted due to a corruption problem or because the media used features your browser did not support.": "La reproducción de vídeo se ha interrumpido por un problema de corrupción de datos o porque el vídeo precisa funciones que su navegador no ofrece.",
 "No compatible source was found for this media.": "No se ha encontrado ninguna fuente compatible con este vídeo."
});

    });
});;
require(["theme_essential/header"], function(amd) { amd.init(); });;
require(["theme_essential/footer"], function(amd) { amd.init(); });;
require(["theme_essential/navbar"], function(amd) { amd.init({"oldnavbar":false}); });;
require(["theme_essential/jBreadCrumb"], function(amd) { amd.init(); });;
require(["theme_essential/fitvids"], function(amd) { amd.init(); });;
require(["tool_usertours/usertours"], function(amd) { amd.init("2", false, 2); });;
require(["block_settings/settingsblock"], function(amd) { amd.init("5", null); });;

require([
    'jquery',
    'core_calendar/selectors',
    'core_calendar/events',
], function(
    $,
    CalendarSelectors,
    CalendarEvents
) {
    var root = $('#month-upcoming-mini-605df8a09058c605df8a0905e21');

    $('body').on(CalendarEvents.filterChanged, function(e, data) {
        M.util.js_pending("month-upcoming-mini-605df8a09058c605df8a0905e21-filterChanged");

        // A filter value has been changed.
        // Find all matching cells in the popover data, and hide them.
        var target = $("#month-upcoming-mini-605df8a09058c605df8a0905e21").find(CalendarSelectors.eventType[data.type]);

        var transitionPromise = $.Deferred();
        if (data.hidden) {
            transitionPromise.then(function() {
                return target.slideUp('fast').promise();
            });
        } else {
            transitionPromise.then(function() {
                return target.slideDown('fast').promise();
            });
        }

        transitionPromise.then(function() {
            M.util.js_complete("month-upcoming-mini-605df8a09058c605df8a0905e21-filterChanged");

            return;
        });

        transitionPromise.resolve();
    });
});
;

require(['jquery', 'core_calendar/calendar_view'], function($, CalendarView) {
    CalendarView.init($("#calendar-upcoming-block-605df8a09058c605df8a0905e21"), 'upcoming');
});
;

require(['jquery', 'theme_bootstrapbase/bootstrap'], function($) {
    require(['theme_bootstrapbase/bootstrap'], function() {
        var target = $("#calendar-day-popover-link-1-2021-84-605df8a09f011605df8a0905e22");
        target.popover({
            content: function() {
                var source = target.next().find("> *:not('.hidden')");
                var content = $('<div>');

                if (source.length) {
                    content.html(source.clone(false));
                } else {
                    content.html(target.data('alternate'));
                }

                return content.html();
            }
        });
    });
});
;

require([
    'jquery',
    'core_calendar/selectors',
    'core_calendar/events',
], function(
    $,
    CalendarSelectors,
    CalendarEvents
) {

    $('body').on(CalendarEvents.filterChanged, function(e, data) {
        M.util.js_pending("month-mini-605df8a09f011605df8a0905e22-filterChanged");
        // A filter value has been changed.
        // Find all matching cells in the popover data, and hide them.
        $("#month-mini-2021-March-605df8a09f011605df8a0905e22")
            .find(CalendarSelectors.popoverType[data.type])
            .toggleClass('hidden', !!data.hidden);
        M.util.js_complete("month-mini-605df8a09f011605df8a0905e22-filterChanged");
    });
});
;

require(['jquery', 'core_calendar/calendar_mini'], function($, CalendarMini) {
    CalendarMini.init($("#calendar-month-2021-March-605df8a09f011605df8a0905e22"), !0);
});
;

require(['core/yui'], function(Y) {
    M.util.init_skiplink(Y);
});
;

require(['jquery', 'message_popup/message_popover_controller'], function($, controller) {
    var container = $('#nav-message-popover-container');
    var controller = new controller(container);
    controller.registerEventListeners();
    controller.registerListNavigationEventListeners();
});
;

require(['jquery', 'message_popup/notification_popover_controller'], function($, controller) {
    var container = $('#nav-notification-popover-container');
    var controller = new controller(container);
    controller.registerEventListeners();
    controller.registerListNavigationEventListeners();
});
;
require(["core/log"], function(amd) { amd.setConfig({"level":"warn"}); });
});
//]]>
</script>
<script type="text/javascript" src="https://gracia.sallenet.org/theme/javascript.php/essential/1614308938/footer"></script>
<script type="text/javascript">
//<![CDATA[
M.str = {"moodle":{"lastmodified":"\u00daltima modificaci\u00f3n","name":"Nombre","error":"Error","info":"Informaci\u00f3n","yes":"S\u00ed","no":"No","cancel":"Cancelar","morehelp":"M\u00e1s ayuda","loadinghelp":"Cargando...","confirm":"Confirmar","areyousure":"\u00bfEst\u00e1 seguro?","closebuttontitle":"Cerrar","unknownerror":"Error desconocido"},"repository":{"type":"Tipo","size":"Tama\u00f1o","invalidjson":"Cadena JSON no v\u00e1lida","nofilesattached":"No se han adjuntado archivos","filepicker":"Selector de archivos","logout":"Salir","nofilesavailable":"No hay archivos disponibles","norepositoriesavailable":"Lo sentimos, ninguno de sus repositorios actuales puede devolver archivos en el formato solicitado.","fileexistsdialogheader":"El archivo existe","fileexistsdialog_editor":"Un archivo con ese nombre ha sido anexado al texto que Usted est\u00e1 editando","fileexistsdialog_filemanager":"Ya ha sido anexado un archivo con ese nombre","renameto":"Cambiar el nombre a \"{$a}\"","referencesexist":"Existen {$a} archivos de alias\/atajos que emplean este archivo como su or\u00edgen","select":"Seleccionar"},"admin":{"confirmdeletecomments":"Est\u00e1 a punto de eliminar comentarios, \u00bfest\u00e1 seguro?","confirmation":"Confirmaci\u00f3n"},"block":{"addtodock":"Minimizar en la barra lateral","undockitem":"Desacoplar este \u00edtem","dockblock":"Acoplar bloque {$a}","undockblock":"Desacoplar bloque {$a}","undockall":"Desacoplar todo","hidedockpanel":"Esconder el panel desacoplado","hidepanel":"Esconder panel"},"langconfig":{"thisdirectionvertical":"btt"}};
//]]>
</script>
<script type="text/javascript">
//<![CDATA[
(function() {Y.use("moodle-filter_mathjaxloader-loader",function() {M.filter_mathjaxloader.configure({"mathjaxconfig":"\nMathJax.Hub.Config({\n  config: [\"MMLorHTML.js\"],\n  jax: [\"input\/TeX\",\"input\/MathML\",\"input\/AsciiMath\",\"output\/HTML-CSS\",\"output\/NativeMML\", \"output\/PreviewHTML\"],\n  extensions: [\"tex2jax.js\",\"mml2jax.js\",\"asciimath2jax.js\",\"MathMenu.js\",\"MathZoom.js\", \"fast-preview.js\", \"AssistiveMML.js\", \"[Contrib]\/a11y\/accessibility-menu.js\"],\n  TeX: {\n    extensions: [\"AMSmath.js\",\"AMSsymbols.js\",\"noErrors.js\",\"noUndefined.js\"]\n  }\n});","lang":"es"});
});
Y.use("moodle-core-dock-loader",function() {M.core.dock.loader.initLoader();
});
M.util.help_popups.setup(Y);
Y.use("moodle-core-popuphelp",function() {M.core.init_popuphelp();
});
M.util.init_block_hider(Y, {"id":"inst19","title":"Sallenet) Mi Sallenet","preference":"block19hidden","tooltipVisible":"Oculta bloque Sallenet) Mi Sallenet","tooltipHidden":"Muestra bloque Sallenet) Mi Sallenet"});
M.util.init_block_hider(Y, {"id":"inst3","title":"Calendario","preference":"block3hidden","tooltipVisible":"Oculta bloque Calendario","tooltipHidden":"Muestra bloque Calendario"});
M.util.init_block_hider(Y, {"id":"inst31852","title":"Mis cursos","preference":"block31852hidden","tooltipVisible":"Oculta bloque Mis cursos","tooltipHidden":"Muestra bloque Mis cursos"});
M.util.init_block_hider(Y, {"id":"inst35865","title":"MENU MAR\u00c7 2021","preference":"block35865hidden","tooltipVisible":"Oculta bloque MENU MAR\u00c7 2021","tooltipHidden":"Muestra bloque MENU MAR\u00c7 2021"});
M.util.init_block_hider(Y, {"id":"inst31891","title":"Eventos pr\u00f3ximos","preference":"block31891hidden","tooltipVisible":"Oculta bloque Eventos pr\u00f3ximos","tooltipHidden":"Muestra bloque Eventos pr\u00f3ximos"});
M.util.init_block_hider(Y, {"id":"inst38350","title":"ALAMBIQUE","preference":"block38350hidden","tooltipVisible":"Oculta bloque ALAMBIQUE","tooltipHidden":"Muestra bloque ALAMBIQUE"});
 M.util.js_pending('random605df8a0905e212'); Y.on('domready', function() { M.util.js_complete("init");  M.util.js_complete('random605df8a0905e212'); });
})();
//]]>
</script>



<!-- Essential theme version: 2018051906 is developed by Gareth J Barnard: about.me/gjbarnard --></body></html><?php /**PATH C:\Users\Jaume\Desktop\Treball\DAM\2020-2021\M06-PHP\newproject-laravel\resources\views/sallenet.blade.php ENDPATH**/ ?>
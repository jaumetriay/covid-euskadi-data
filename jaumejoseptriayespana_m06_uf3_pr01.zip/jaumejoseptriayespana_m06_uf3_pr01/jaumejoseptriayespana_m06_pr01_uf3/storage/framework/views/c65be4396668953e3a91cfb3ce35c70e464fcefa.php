<!DOCTYPE html> 

<head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">


        <link rel="stylesheet" href="http://cdn.oesmith.co.uk/morris-0.5.1.css">
        <script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.0/jquery.min.js"></script>
        <script src="//cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
        <script src="http://cdn.oesmith.co.uk/morris-0.5.1.min.js"></script>
  
 
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('spam.css')); ?>" >


        <title><?php echo $__env->yieldContent('title','covid'); ?></title>
</head>

<body>
      <header>
      <div class="title-margin"><?php echo $__env->yieldContent('header', 'sample-header'); ?></div>

      </header>


 
      <nav role="navigation">
      <div id="menuToggle">
 
  
      <input type="checkbox" />
      

 
      <span></span>
      <span></span>
      <span></span>

 
      <ul id="menu">
        <a href="/spam-home"><li>Home</li></a>
        <a href="/spam-about"><li>About</li></a>
        <a href="/spam-classification"><li>Spam Classification</li></a> 
        <a href="/spam-contact"><li>Contact</li></a> 
        <a href="/spam-form"><li>Spam Form</li></a> 
        
        
      </ul>
      </div>
      </nav>


</body>
<footer>
<?php echo $__env->yieldContent('footer','La Salle Gràcia.  jaumejosep.triay@gracia.lasalle.cat'); ?>
</footer>





</html><?php /**PATH C:\Users\Jaume\Desktop\Treball\DAM\2020-2021\M06-PHP\m06_pr01_uf3\resources\views/covid-layout.blade.php ENDPATH**/ ?>
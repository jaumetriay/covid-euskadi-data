<!DOCTYPE html>
</html>
<?php /**PATH C:\Users\Jaume\Desktop\Treball\DAM\2020-2021\M06-PHP\newproject-laravel\resources\views/contact-ex4.blade.php ENDPATH**/ ?>
<!DOCTYPE html> 
<body>

<title><?php echo $__env->yieldContent('content', 'defaultTitle'); ?></title>
<ul>
  
  
  <li><a href="/contact-04">Contact</a></li>
  <li><a href="/about-04">About</a></li>
 
</ul>
</body>
</html>
<?php /**PATH C:\Users\Jaume\Desktop\Treball\DAM\2020-2021\M06-PHP\newproject-laravel\resources\views/layout.blade.php ENDPATH**/ ?>
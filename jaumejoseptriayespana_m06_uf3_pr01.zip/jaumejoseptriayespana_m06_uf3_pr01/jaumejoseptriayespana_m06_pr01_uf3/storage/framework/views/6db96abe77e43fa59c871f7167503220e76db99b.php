

<?php $__env->startSection('header'); ?>
Contact
<?php $__env->stopSection(); ?>

 
<div class= "home-image justify"  > 
<ul> 
    <li>Tel: 692 45 27 34</li></a>
    <li>Name: Jaume</li></a>
    <li>e-mail: jaumejosep.triay@lasalle.gracia.cat</li></a> 
 
        

</ul>
</div>
<?php echo $__env->make('spam-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Jaume\Desktop\Treball\DAM\2020-2021\M06-PHP\newproject-laravel\resources\views/spam-contact.blade.php ENDPATH**/ ?>
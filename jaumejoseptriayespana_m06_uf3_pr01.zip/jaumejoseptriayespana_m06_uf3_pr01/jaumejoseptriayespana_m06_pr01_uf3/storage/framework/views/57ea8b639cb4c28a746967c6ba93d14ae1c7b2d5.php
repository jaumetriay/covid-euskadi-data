

 

<?php $__env->startSection('header'); ?>
Covid
<?php $__env->stopSection(); ?>


<div class="home-image justify">

<form action="/covid" method="POST">
  <?php echo csrf_field(); ?> 
    <input id="button" type="submit" value="Update Data" name="updateValues">
  </form>

   


</div>


<?php echo $__env->make('covid-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Jaume\Desktop\Treball\DAM\2020-2021\M06-PHP\m06_pr01_uf3\resources\views/covid.blade.php ENDPATH**/ ?>


<?php $__env->startSection('header'); ?>
Result
<?php $__env->stopSection(); ?>
<div class="home-image justify">

    <?php

        // if(isset($_POST["spam"]))
        //         echo $name; 
        if(isset($_POST["spam"]))
            echo "The message ";
            
    ?>

    <span class="cursive">
        <?php
            
            if(isset($_POST["spam"]))
                echo '"' . $message . '"'; 
        ?>
    </span>

    <?php
            
            if(isset($_POST["spam"]))
               echo  " is a ". $result; 
    ?>


</div>

    
 
    
 

</div>

<?php echo $__env->make('spam-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Jaume\Desktop\Treball\DAM\2020-2021\M06-PHP\newproject-laravel\resources\views/spam-result.blade.php ENDPATH**/ ?>
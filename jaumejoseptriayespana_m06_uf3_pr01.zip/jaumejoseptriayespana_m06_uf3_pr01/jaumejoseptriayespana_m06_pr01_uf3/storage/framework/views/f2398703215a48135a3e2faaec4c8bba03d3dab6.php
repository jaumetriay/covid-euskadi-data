

<?php $__env->startSection('header'); ?>
Classification
<?php $__env->stopSection(); ?>

<?php echo $__env->make('spam-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Jaume\Desktop\Treball\DAM\2020-2021\M06-PHP\newproject-laravel\resources\views/spam-spamclassification.blade.php ENDPATH**/ ?>


 

<?php $__env->startSection('header'); ?>
About
<?php $__env->stopSection(); ?>

<div class="home-image justify">


"La Salle Gràcia és un col·legi privat concertat d'ensenyament preuniversitari que forma part de la xarxa d'escoles La Salle, 
la qual aposta per un projecte educatiu basat en una oferta de valors cristians al servei d'una formació de qualitat i que dóna
 resposta a les necessitats del món actual. El nostre model educatiu es sustenta per quatre eixos: atenció personalitzada, 
 estil pedagògic innovador, educació en valors i aprenentatge tecnològic i pràctic per encarar els reptes de futur. 
 Gràcies a aquests pilars i als nostres valors: responsabilitat, creativitat, convivència, justícia, interioritat i trascendència, 
 el nostre col·legi es caracteritza pel seu caràcter propim implicat en l'aprenetatge i creixement de tots els infants i joves."

</div>
<?php echo $__env->make('spam-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Jaume\Desktop\Treball\DAM\2020-2021\M06-PHP\newproject-laravel\resources\views/spam-about.blade.php ENDPATH**/ ?>


<?php $__env->startSection('header'); ?>
Form
<?php $__env->stopSection(); ?>

<div class = " home-image justify">

  <form action="/spam-result" method="POST">
  <?php echo csrf_field(); ?>
    <input class="cursive" type="text" name="spam" autocomplete="off" spellcheck="false" placeholder="write your message.." >
    <input id="button" type="submit" value="Evaluate" name="button">
  </form>

  <small>Message must contain 25 characters or more. </small>
 
</div>


<?php echo $__env->make('spam-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Jaume\Desktop\Treball\DAM\2020-2021\M06-PHP\newproject-laravel\resources\views/spam-spamform.blade.php ENDPATH**/ ?>